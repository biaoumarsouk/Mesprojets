#!/bin/bash

echo "🔧 [INSTALL] Installation complète de Save Config Pro..."

cd "$(dirname "$0")"

# Vérification des droits root
if [ "$EUID" -ne 0 ]; then
  echo "🔐 Ce script nécessite les droits administrateur (sudo)."
  exec sudo "$0" "$@"
  exit
fi

# Attente si dpkg est verrouillé
echo "⏳ Vérification du verrou dpkg..."
while fuser /var/lib/dpkg/lock >/dev/null 2>&1 || \
      fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do
    echo "[🔒] Attente libération du gestionnaire de paquets..."
    sleep 2
done

# =============================
# 🔹 1. Installer les paquets système
# =============================
echo "📦 Installation des paquets système..."
apt update
apt install -y python3-pip software-properties-common inotify-tools vsftpd ansible

# =============================
# 🔹 2. Créer l'utilisateur FTP
# =============================
USERNAME="ftpuser"
PASSWORD="Ftpuser57"
HOME="/home/$USERNAME"

if id "$USERNAME" &>/dev/null; then
    echo "👤 Utilisateur $USERNAME déjà existant."
else
    echo "👤 Création de l'utilisateur FTP..."
    useradd -m -d "$HOME" -s /bin/bash "$USERNAME"
    echo "$USERNAME:$PASSWORD" | chpasswd
    echo "$USERNAME" >> /etc/vsftpd.userlist
fi

chown "$USERNAME:$USERNAME" "$HOME"
chmod 755 "$HOME"
echo "✅ Utilisateur $USERNAME prêt."

# =============================
# 🔹 3. Configurer vsftpd
# =============================
echo "⚙️ Configuration de vsftpd..."
cp /etc/vsftpd.conf /etc/vsftpd.conf.bak

cat > /etc/vsftpd.conf <<EOF
listen=YES
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
chroot_local_user=YES
allow_writeable_chroot=YES
userlist_enable=YES
userlist_file=/etc/vsftpd.userlist
userlist_deny=NO
pasv_enable=YES
pasv_min_port=40000
pasv_max_port=50000
EOF

systemctl enable vsftpd
systemctl restart vsftpd
echo "✅ Serveur FTP démarré."

# =============================
# 🔹 4. Service de hash automatique
# =============================
echo "🛡️ Mise en place du service de hachage automatique..."

HASH_SCRIPT="/usr/local/bin/hash_watcher.sh"
cat > "$HASH_SCRIPT" <<'EOL'
#!/bin/bash
WATCH_DIR="/home/ftpuser"

inotifywait -m -e close_write --format "%w%f" "$WATCH_DIR" | while read FILE
do
    if [[ "$FILE" != *.sha256 ]]; then
        SHA_FILE="${FILE}.sha256"
        if [ ! -f "$SHA_FILE" ]; then
            sha256sum "$FILE" > "$SHA_FILE"
            echo "[HASH] $FILE → $SHA_FILE"
        else
            echo "[IGNORÉ] $SHA_FILE existe déjà"
        fi
    fi
done
EOL

chmod +x "$HASH_SCRIPT"

cat > /etc/systemd/system/hashwatcher.service <<EOF
[Unit]
Description=Hash automatique des fichiers FTP
After=network.target

[Service]
ExecStart=$HASH_SCRIPT
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable hashwatcher
systemctl restart hashwatcher
echo "✅ Service hashwatcher actif."

# =============================
# 🔹 5. Installer les dépendances Python
# =============================
DEPENDANCES=(
  paramiko
  psutil
  Pillow
  matplotlib
  watchdog
  ansible-pylibssh
)

echo "🐍 Installation des bibliothèques Python..."
for package in "${DEPENDANCES[@]}"; do
  echo "📦 pip install $package"
  pip install "$package" --break-system-packages
done

# =============================
# 🔹 6. Fin
# =============================
echo ""
echo "🎉 Installation complète terminée avec succès !"
echo "✅ Serveur FTP opérationnel"
echo "✅ Hachage automatique actif"
echo "✅ Ansible installé"
echo ""
echo "ℹ️ Lancez l'application avec :"
echo "   python3 main.py"
