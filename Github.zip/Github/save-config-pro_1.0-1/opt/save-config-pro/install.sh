#!/bin/bash

echo "🔧 Installation globale des dépendances..."

# Aller dans le dossier du projet
cd "$(dirname "$0")"

# Vérifie si on est root
if [ "$EUID" -ne 0 ]; then
  echo "🔐 Ce programme nécessite les droits administrateur (sudo)."
  exec sudo "$0" "$@"
  exit
fi

# =============================
# 🔹 1. Installer les paquets système
# =============================
echo "📦 Installation des paquets système (Ansible, vsftpd)..."
apt update
apt install -y python3-pip ansible vsftpd

# =============================
# 🔹 2. Créer l'utilisateur FTP
# =============================
USERNAME="ftpuser"
PASSWORD="Ftpuser57"

if id "$USERNAME" &>/dev/null; then
  echo "👤 Utilisateur $USERNAME déjà existant."
else
  echo "👤 Création de l'utilisateur FTP $USERNAME..."
  useradd -m -s /bin/bash "$USERNAME"
  echo "$USERNAME:$PASSWORD" | chpasswd
  echo "$USERNAME" | tee -a /etc/vsftpd.userlist
fi

# =============================
# 🔹 3. Configurer le serveur FTP (vsftpd)
# =============================
echo "⚙️ Configuration de vsftpd..."

# Sauvegarde ancienne config si jamais
cp /etc/vsftpd.conf /etc/vsftpd.conf.bak

cat > /etc/vsftpd.conf <<EOF
listen=YES
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
chroot_local_user=YES
allow_writeable_chroot=YES
userlist_enable=YES
userlist_file=/etc/vsftpd.userlist
userlist_deny=NO
pasv_enable=YES
pasv_min_port=40000
pasv_max_port=50000
EOF

# Démarrer le service FTP
systemctl restart vsftpd
systemctl enable vsftpd
echo "✅ Serveur FTP configuré et démarré."

# =============================
# 🔹 4. Installer les dépendances Python
# =============================
DEPENDANCES=(
  paramiko
  psutil
  Pillow
  matplotlib
  watchdog
  ansible-pylibssh
)

echo "🐍 Installation des bibliothèques Python..."
for package in "${DEPENDANCES[@]}"; do
  echo "📦 Installation de $package..."
  pip install "$package" --break-system-packages
done

# =============================
# 🔹 5. Lancer l'application
# =============================
echo "🚀 Lancement de Save Config Pro..."
python3 main.py
