from app import NetworkConfigApp

def main():
    app = NetworkConfigApp()
    app.mainloop()

if __name__ == "__main__":
    main()