import os
import time
import shlex
import subprocess
import paramiko
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class SyncHandler(FileSystemEventHandler):
    def __init__(self, local_dir, servers):
        self.local_dir = local_dir
        self.servers = servers

    def on_any_event(self, event):
        print(f"[🔔] Modification détectée : {event.src_path}")
        for server in self.servers:
            self.sync_to_remote(server)

    def sync_to_remote(self, server):
        ip = server["ip"]
        username = server["username"]
        remote_path = server["remote_dir"]

        rsync_cmd = (
            f"rsync -az "
            f"-e 'ssh -i ~/.ssh/id_rsa -o StrictHostKeyChecking=no' "
            f"{shlex.quote(self.local_dir)}/ {username}@{ip}:{shlex.quote(remote_path)}/"
        )

        print(f"[🔁] Synchronisation vers {ip}...")
        result = subprocess.run(rsync_cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"[✅] Synchronisation réussie vers {ip}.")
        else:
            print(f"[❌] Erreur Rsync vers {ip} : {result.stderr}")

def installer_dependances_locales():
    print("[📦] Installation des dépendances locales...")
    try:
        subprocess.run(["sudo", "apt", "install", "-y", "rsync", "sshpass"], check=True)
        print("[✅] Dépendances locales installées.\n")
    except Exception as e:
        print(f"[❌] Erreur installation locale : {e}")
        return False
    return True

def installer_dependances_distantes(ssh):
    print("[🌐] Installation des dépendances sur le serveur distant...")
    cmd = "apt update && apt install -y rsync openssh-server vsftpd"
    stdin, stdout, stderr = ssh.exec_command(f"sudo bash -c {shlex.quote(cmd)}")
    stdout.channel.recv_exit_status()
    print("[✅] Dépendances distantes installées.")

def charger_serveurs(json_path):
    try:
        with open(json_path, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"[❌] Impossible de lire le fichier JSON : {e}")
        return []

def lancer_synchronisation_multi_serveurs():
    print("=== Synchronisation automatique multi-serveurs ===")

    if not installer_dependances_locales():
        return

    json_path = os.path.join(os.path.dirname(__file__), "..", "files", "serveur_distants.json")
    serveurs = charger_serveurs(json_path)

    if not serveurs:
        print("[⚠️] Aucun serveur enregistré trouvé.")
        return

    local_dir = "/home/ftpuser"
    print(f"[📁] Dossier local surveillé : {local_dir}")

    for server in serveurs:
        ip = server["ip"]
        username = server["username"]
        password = server.get("password", "")
        server["remote_dir"] = f"/home/{username}/ftp_backups_distant"

        print(f"[🔗] Connexion à {ip}...")
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            if password:
                ssh.connect(ip, username=username, password=password, timeout=10)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=10)

            print(f"[✅] Connexion réussie à {ip}")
            installer_dependances_distantes(ssh)
            ssh.exec_command(f"mkdir -p {server['remote_dir']}")
            ssh.close()
        except Exception as e:
            print(f"[❌] Erreur connexion SSH à {ip} : {e}")

    print("[👀] Démarrage de la surveillance du dossier local...")
    event_handler = SyncHandler(local_dir, serveurs)
    observer = Observer()
    observer.schedule(event_handler, local_dir, recursive=True)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[⏹️] Arrêt par l'utilisateur.")
        observer.stop()
    observer.join()
