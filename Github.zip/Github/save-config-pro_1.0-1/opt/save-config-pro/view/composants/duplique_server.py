import os
import time
import shlex
import subprocess
import paramiko
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class SyncHandler(FileSystemEventHandler):
    def __init__(self, local_dir, servers):
        self.local_dir = local_dir
        self.servers = servers
        self.sync_en_cours = False
        self.use_ssh_key_for = set()  # IPs des serveurs où la clé SSH a déjà réussi

    def on_any_event(self, event):
        if not event.is_directory:
            if self.sync_en_cours:
                print("[⏳] Une synchronisation est déjà en cours. Événement ignoré.")
                return

            print(f"[🔔] Modification détectée : {event.src_path}")
            self.sync_en_cours = True
            try:
                for server in self.servers:
                    self.sync_to_remote(server)
            finally:
                self.sync_en_cours = False

    def sync_to_remote(self, server):
        ip = server["ip"]
        username = server["username"]
        password = server.get("password", "")
        remote_path = server["remote_dir"]
        ssh_key = os.path.expanduser("~/.ssh/id_rsa")

        # 🔐 Tentative avec clé SSH si elle a déjà fonctionné
        if ip in self.use_ssh_key_for:
            rsync_cmd_key = (
                f"rsync -az "
                f"-e 'ssh -i {ssh_key} -o StrictHostKeyChecking=no -o PreferredAuthentications=publickey' "
                f"{shlex.quote(self.local_dir)}/ {username}@{ip}:{shlex.quote(remote_path)}/"
            )
            print(f"[🔁] Synchronisation vers {ip} avec clé SSH...")
            result = subprocess.run(rsync_cmd_key, shell=True, capture_output=True, text=True)

            if result.returncode == 0:
                print(f"[✅] Synchronisation réussie vers {ip} avec clé SSH.")
                return
            else:
                print(f"[⚠️] Clé SSH refusée pour {ip}, basculement vers mot de passe.")
                self.use_ssh_key_for.remove(ip)

        # 🔑 Tentative avec mot de passe via sshpass
        rsync_cmd_pw = (
            f"sshpass -p {shlex.quote(password)} "
            f"rsync -az -e 'ssh -o StrictHostKeyChecking=no' "
            f"{shlex.quote(self.local_dir)}/ {username}@{ip}:{shlex.quote(remote_path)}/"
        )
        print(f"[🔁] Synchronisation vers {ip} avec mot de passe...")
        result = subprocess.run(rsync_cmd_pw, shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            print(f"[✅] Synchronisation réussie vers {ip} avec mot de passe.")
        else:
            print(f"[❌] Échec de la synchronisation vers {ip} :\n{result.stderr}")


def installer_dependances_locales():
    print("[📦] Installation des dépendances locales...")
    try:
        subprocess.run(["sudo", "apt", "install", "-y", "rsync", "sshpass"], check=True)
        print("[✅] Dépendances locales installées.\n")
    except Exception as e:
        print(f"[❌] Erreur installation locale : {e}")
        return False
    return True


def installer_dependances_distantes(ssh):
    print("[🌐] Installation des dépendances sur le serveur distant...")
    cmd = "apt update && apt install -y rsync openssh-server vsftpd"
    stdin, stdout, stderr = ssh.exec_command(f"sudo bash -c {shlex.quote(cmd)}")
    stdout.channel.recv_exit_status()
    print("[✅] Dépendances distantes installées.")


def charger_serveurs(json_path):
    try:
        with open(json_path, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"[❌] Impossible de lire le fichier JSON : {e}")
        return []


def lancer_synchronisation_multi_serveurs():
    print("=== Synchronisation automatique multi-serveurs ===")

    if not installer_dependances_locales():
        return None

    json_path = os.path.join(os.path.dirname(__file__), "..", "files", "serveur_distants.json")
    serveurs = charger_serveurs(json_path)

    if not serveurs:
        print("[⚠️] Aucun serveur enregistré trouvé.")
        raise ValueError("Aucun serveur distant enregistré trouvé.")

    local_dir = "/home/ftpuser"
    print(f"[📁] Dossier local surveillé : {local_dir}")

    # Configuration des chemins distants
    for server in serveurs:
        ip = server["ip"]
        username = server["username"]
        password = server.get("password", "")
        server["remote_dir"] = f"/home/{username}/ftp_backups_distant"

        print(f"[🔗] Connexion à {ip}...")
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            if password:
                ssh.connect(ip, username=username, password=password, timeout=10)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=10)

            print(f"[✅] Connexion réussie à {ip}")
            installer_dependances_distantes(ssh)
            ssh.exec_command(f"mkdir -p {server['remote_dir']}")
            ssh.close()
        except Exception as e:
            print(f"[❌] Erreur connexion SSH à {ip} : {e}")

    # 🔄 Création unique du gestionnaire
    handler = SyncHandler(local_dir, serveurs)

    print("[🚀] Lancement de la synchronisation initiale vers tous les serveurs...")
    for server in serveurs:
        handler.sync_to_remote(server)

    print("[👀] Démarrage de la surveillance du dossier local...")
    observer = Observer()
    observer.schedule(handler, local_dir, recursive=True)
    observer.start()

    return observer  # 💡 Permet d'arrêter proprement avec observer.stop()
