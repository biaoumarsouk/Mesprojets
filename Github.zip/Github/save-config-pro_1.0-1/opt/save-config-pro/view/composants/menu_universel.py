import tkinter as tk
from tkinter import messagebox
import subprocess
import threading
from tkinter import ttk
import sys
import os # Ajout de l'import os
import json
import paramiko
import hashlib


class MenuUniversel(tk.Frame):
    def __init__(self, root, theme_manager):
        super().__init__(root, width=220)
        self.root = root
        self.theme_manager = theme_manager
        self.submenus = {}
        self.theme_manager.register_widget(self, bg_prop='bg_secondary') # Utilisation de mot-clé
        self.pack_propagate(False)

    def set_current_user(self, username):
        self.current_user = username
        role = self.root.get_user_role(username)

        base_menu = {
            "Gérer le serveur": {
                "Redémarrer le serveur": self.restart_server,
                "Réinstaller le serveur": self.reinstal_server,
            },
            "Gérer Ansible": {
                "Mettre à jour ansible": self.install_ansible,
            }
        }
        if role == "admin":
            base_menu["Gérer le serveur"]["Créer un serveur distant"] = self.enregistrer_serveur_ftp_distant
            base_menu["Gérer le serveur"]["Synchroniser à distance"] = self.duplicate_serveur
            base_menu["Gérer le serveur"]["Désinstaller le serveur"] = self.desinstall_server
            base_menu["Gérer le serveur"]["Supprimer les sauvegardes"] = self.efface_sauvegarde
            base_menu["Gérer Ansible"]["Désinstaller ansible"] = self.desintall_ansible
        
        self.menu_structure = base_menu
        self._clear_menu_widgets()
        self.create_menu_widgets()

    def _clear_menu_widgets(self):
        for widget in self.winfo_children():
            widget.destroy()

    def create_menu_widgets(self):
        # ... (début inchangé) ...
        self.title_label = tk.Label(self)
        self.theme_manager.register_widget(self.title_label, bg_prop='bg_secondary', fg_prop='fg_main')
        self.title_label.pack(pady=2)
        
        self.menu_title = tk.Label(self, text=" Outils systèmes", font=("Helvetica", 12, "bold"), anchor="center")
        self.theme_manager.register_widget(self.menu_title, bg_prop='bg_secondary', fg_prop='fg_main')
        self.menu_title.pack(pady=2)

        self.separator = tk.Frame(self, height=1) # Mettre une hauteur de 1 pour être visible
        self.theme_manager.register_widget(self.separator, bg_prop='separator')
        self.separator.pack(fill='x', padx=5, pady=5)
        # --- (fin de la partie inchangée) ---

        for group, actions in self.menu_structure.items():
            self.create_menu_group(group, actions)

    def create_menu_group(self, group_name, actions_dict):
        group_container = tk.Frame(self)
        self.theme_manager.register_widget(group_container, bg_prop='bg_secondary')
        group_container.pack(fill="x", anchor="w")

        submenu_frame = tk.Frame(self)
        self.theme_manager.register_widget(submenu_frame, bg_prop='bg_secondary')

        def toggle_submenu():
            visible = self.submenus.get(group_name, False)
            if visible:
                submenu_frame.pack_forget()
                btn.config(text=f"{group_name}  ▶")
            else:
                submenu_frame.pack(after=group_container, fill="x", anchor="w")
                btn.config(text=f"{group_name}  ▼")
            self.submenus[group_name] = not visible

        btn = tk.Button(group_container, text=f"{group_name}  ▶", anchor="w", command=toggle_submenu, font=("Helvetica", 11, "bold"), relief="flat", bd=0, highlightthickness=0, padx=20, pady=6)
        
        ### CORRECTION ICI ###
        self.theme_manager.register_widget(
            btn, 
            bg_prop='bg_secondary', 
            fg_prop='fg_main',
            active_bg='bg_hover',  # Pour la couleur au clic
            active_fg='fg_main'    # Garder la même couleur de texte au clic
        )
        
        # Le code pour le survol est correct car il est géré séparément
        btn.bind("<Enter>", lambda e: btn.config(bg=self.theme_manager.bg_hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=self.theme_manager.bg_secondary))
        btn.pack(fill="x")

        for label, cmd in actions_dict.items():
            sub_btn = tk.Button(submenu_frame, text=f" • {label}", command=cmd, font=("Helvetica", 11), relief="flat", anchor="w", padx=30, pady=4, bd=0, highlightthickness=0)
            
            ### CORRECTION ICI ###
            self.theme_manager.register_widget(
                sub_btn, 
                bg_prop='bg_secondary', 
                fg_prop='fg_main',
                active_bg='bg_hover', # Pour la couleur au clic
                active_fg='fg_main'   # Garder la même couleur de texte au clic
            )
            
            # Le code pour le survol est correct
            sub_btn.bind("<Enter>", lambda e, b=sub_btn: b.config(bg=self.theme_manager.bg_hover))
            sub_btn.bind("<Leave>", lambda e, b=sub_btn: b.config(bg=self.theme_manager.bg_secondary))
            sub_btn.pack(fill="x")


    def restart_server(self):
        """Action pour redémarrer le serveur (exemple avec un message)"""
        if messagebox.askyesno("Confirmation", "Voulez-vous vraiment redémarrer le serveur ?"):
            def run_1():
                try:
                    subprocess.run(["sudo", "systemctl", "start", "vsftpd"], check=True)
                    messagebox.showinfo("Action", "Le serveur a été redémarré.")
                except subprocess.CalledProcessError as e:
                    messagebox.showerror("Erreur", f"Échec du redémarrage : {e}")
            
            threading.Thread(target=run_1).start()


    def duplicate_serveur(self):
        import threading
        from .duplique_server import lancer_synchronisation_multi_serveurs

        def run_script():
            try:
                lancer_synchronisation_multi_serveurs()
            except Exception as e:
                messagebox.showerror("Erreur", f"Échec de synchronisation : {e}")

        threading.Thread(target=run_script, daemon=True).start()



    
    def reinstal_server(self):
        if messagebox.askyesno("Confirmation", "Voulez-vous vraiment réinstaller le serveur sans perdre vos données ?"):

            def run_command(command, check=True):
                try:
                    subprocess.run(command, check=check)
                except subprocess.CalledProcessError as e:
                    print(f"Erreur lors de l'exécution : {' '.join(command)}\n{e}")

            def update_vsftpd_conf():
                print("📄 Mise à jour de la configuration vsftpd...")
                config_path = "/etc/vsftpd.conf"
                options = {
                    "write_enable": "YES",
                    "local_umask": "022",
                    "local_enable": "YES",
                    "chroot_local_user": "YES",
                    "allow_writeable_chroot": "YES"
                }

                with open(config_path, 'r') as file:
                    lines = file.readlines()

                updated_lines = []
                for line in lines:
                    key_found = False
                    for key in options:
                        if line.strip().startswith(key):
                            updated_lines.append(f"{key}={options[key]}\n")
                            key_found = True
                            break
                    if not key_found:
                        updated_lines.append(line)

                for key, value in options.items():
                    if not any(l.strip().startswith(key) for l in updated_lines):
                        updated_lines.append(f"{key}={value}\n")

                with open(config_path, 'w') as file:
                    file.writelines(updated_lines)
                print("✅ vsftpd.conf mis à jour.")

            def configure_auto_hash():
                print("⚙️ Configuration du hash automatique...")

                # Installer inotify-tools
                run_command(['sudo', 'apt', 'install', '-y', 'inotify-tools'])

                # Créer le script bash
                script_path = "/usr/local/bin/hash_watcher.sh"
                script_content = """#!/bin/bash
    WATCH_DIR="/home/ftpuser"

    inotifywait -m -e close_write --format "%w%f" "$WATCH_DIR" | while read FILE
    do
        if [[ "$FILE" != *.sha256 ]]; then
            SHA_FILE="${FILE}.sha256"
            if [ ! -f "$SHA_FILE" ]; then
                sha256sum "$FILE" > "$SHA_FILE"
                echo "[HASH] $FILE → $SHA_FILE"
            else
                echo "[IGNORÉ] $SHA_FILE existe déjà"
            fi
        fi
    done
    """

                with open("temp_hash.sh", "w") as f:
                    f.write(script_content)

                run_command(['sudo', 'mv', 'temp_hash.sh', script_path])
                run_command(['sudo', 'chmod', '+x', script_path])

                # Créer le service systemd
                service_content = """[Unit]
    Description=Hash automatique des fichiers FTP
    After=network.target

    [Service]
    ExecStart=/usr/local/bin/hash_watcher.sh
    Restart=always
    User=root

    [Install]
    WantedBy=multi-user.target
    """

                with open("temp_hash.service", "w") as f:
                    f.write(service_content)

                run_command(['sudo', 'mv', 'temp_hash.service', '/etc/systemd/system/hashwatcher.service'])

                # Activer le service
                run_command(['sudo', 'systemctl', 'daemon-reload'])
                run_command(['sudo', 'systemctl', 'enable', 'hashwatcher'])
                run_command(['sudo', 'systemctl', 'restart', 'hashwatcher'])

                print("✅ Service hashwatcher actif.")

            def install_vsftpd():
                print("📦 Installation de vsftpd...")
                run_command(['sudo', 'apt', 'update'])
                run_command(['sudo', 'apt', 'install', '-y', 'vsftpd'])
                update_vsftpd_conf()
                run_command(['sudo', 'systemctl', 'enable', 'vsftpd'])
                run_command(['sudo', 'systemctl', 'restart', 'vsftpd'])
                print("✅ vsftpd installé et configuré.")

            def create_ftp_user():
                username = "ftpuser"
                password = "Ftpuser57"
                home_dir = f"/home/{username}"

                print(f"👤 Création de l'utilisateur FTP : {username}")
                try:
                    subprocess.run(['id', username], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                    print("ℹ️ Utilisateur déjà existant.")
                except subprocess.CalledProcessError:
                    subprocess.run(['sudo', 'useradd', '-m', '-d', home_dir, username], check=True)
                    subprocess.run(f"echo '{username}:{password}' | sudo chpasswd", shell=True, check=True)

                run_command(['sudo', 'chown', f"{username}:{username}", home_dir])
                run_command(['sudo', 'chmod', '755', home_dir])
                print("✅ Utilisateur FTP prêt.")

            def main():
                install_vsftpd()
                create_ftp_user()
                configure_auto_hash()
                print("🎉 Serveur FTP réinstallé avec succès.")
                messagebox.showinfo("Succès", "Le serveur FTP a été réinstallé et le hachage automatique est actif.")

            threading.Thread(target=main).start()


    def desinstall_server(self):
        if messagebox.askyesno("Confirmation", "Voulez-vous vraiment désinstaller le serveur et perdre vos données ?"):

            def run():
                try:
                    print("Désinstallation de vsftpd...")
                    subprocess.run(['sudo', 'apt', 'remove', '--purge', 'vsftpd', '-y'], check=True)

                    print("Suppression des fichiers de configuration...")
                    subprocess.run(['sudo', 'rm', '-rf', '/etc/vsftpd.conf', '/etc/vsftpd*'], check=True)

                    print("Suppression du service hashwatcher...")
                    subprocess.run(['sudo', 'systemctl', 'stop', 'hashwatcher'])
                    subprocess.run(['sudo', 'systemctl', 'disable', 'hashwatcher'])
                    subprocess.run(['sudo', 'rm', '-f', '/etc/systemd/system/hashwatcher.service'])
                    subprocess.run(['sudo', 'rm', '-f', '/usr/local/bin/hash_watcher.sh'])

                    print("Suppression de l'utilisateur FTP...")
                    subprocess.run(['sudo', 'userdel', '-r', 'ftpuser'], check=True)

                    print("Désactivation de vsftpd au démarrage...")
                    subprocess.run(['sudo', 'systemctl', 'disable', 'vsftpd'])

                    print("✅ Suppression de vsftpd et hashwatcher terminée.")
                    messagebox.showinfo("Succès", "Le serveur FTP a été désinstallé avec succès.")

                except subprocess.CalledProcessError as e:
                    print(f"Erreur lors de la suppression : {e}")
                    messagebox.showerror("Erreur critique", f"Erreur pendant la désinstallation :\n{e}")

            threading.Thread(target=run).start()




    def desintall_ansible(self):
        if messagebox.askyesno("Confirmation", "Voulez-vous vraiment désinstaller ansible ?"):
            def is_ansible_installed():
                try:
                    # Vérifier si Ansible est installé en utilisant `which`
                    subprocess.check_call(["which", "ansible"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    return True
                except subprocess.CalledProcessError:
                    return False

            def uninstall_ansible():
                if not is_ansible_installed():
                    messagebox.showinfo("Succès", "Ansible n'est pas installé sur ce système.")
                    print("Ansible n'est pas installé sur ce système.")
                    return  # Si Ansible n'est pas installé, on arrête le script.

                try:
                    # Désinstallation d'Ansible
                    print("Désinstallation d'Ansible...")
                    subprocess.check_call(["sudo", "apt", "remove", "-y", "ansible"])

                    # Suppression des fichiers de configuration
                    print("Suppression des fichiers de configuration...")
                    subprocess.check_call(["sudo", "apt", "purge", "-y", "ansible"])

                    # Suppression des dépendances inutilisées
                    print("Suppression des dépendances inutilisées...")
                    subprocess.check_call(["sudo", "apt", "autoremove", "-y"])

                    print("Ansible a été désinstallé avec succès!")
                    messagebox.showinfo("Succès", "Ansible a été bien désinstallé")
                    # Vérification que Ansible a bien été désinstallé
                    if not is_ansible_installed():
                        print("Ansible a bien été désinstallé.")
                    else:
                        print("Erreur : Ansible est toujours installé.")
                    
                except subprocess.CalledProcessError as e:
                    print(f"Erreur lors de la désinstallation : {e}")
                    sys.exit(1)

            threading.Thread(target=uninstall_ansible).start()

    def install_ansible(self):
        if messagebox.askyesno("Confirmation", "Voulez-vous vraiment réinstaller ansible?"):
            def inst_ansible():
                try:
                    # Mise à jour des paquets système
                    print("Mise à jour des paquets système...")
                    subprocess.check_call(["sudo", "apt", "update", "-y"])
                    subprocess.check_call(["sudo", "apt", "upgrade", "-y"])

                    # Installer les dépendances nécessaires
                    print("Installation des dépendances...")
                    subprocess.check_call(["sudo", "apt", "install", "-y", "software-properties-common"])

                    # Ajouter le dépôt d'Ansible
                    print("Ajout du dépôt d'Ansible...")
                    subprocess.check_call(["sudo", "add-apt-repository", "--yes", "ppa:ansible/ansible"])

                    # Mettre à jour après ajout du dépôt
                    print("Mise à jour des paquets après ajout du dépôt...")
                    subprocess.check_call(["sudo", "apt", "update", "-y"])

                    # Installer Ansible
                    print("Installation d'Ansible...")
                    subprocess.check_call(["sudo", "apt", "install", "-y", "ansible"])

                    # Vérification de l'installation d'Ansible
                    print("Vérification de l'installation d'Ansible...")
                    subprocess.check_call(["ansible", "--version"])

                    print("Ansible a été installé avec succès!")
                    messagebox.showinfo("Succès", "Ansible a été mis à jour avec succès")
                except subprocess.CalledProcessError as e:
                    print(f"Erreur lors de l'installation : {e}")
                    sys.exit(1)
            threading.Thread(target=inst_ansible).start()


    def efface_sauvegarde(self):
        """Supprime tous les fichiers .cfg et .rsc du dossier /home/ftpuser avec sudo"""
        if messagebox.askyesno(
            "Confirmation", 
            "Voulez-vous vraiment supprimer toutes les sauvegardes?\n"
            "Cette action est irréversible !"
        ):

            def run_delete():
                try:
                    # Récupération de la liste des fichiers
                    result = subprocess.run(
                        ["sudo", "find", "/home/ftpuser", "(", 
                            "-name", "*.cfg", "-o", 
                            "-name", "*.cfg.sha256", "-o",
                            "-name", "*.rsc", "-o", 
                            "-name", "*.rsc.sha256", 
                        ")"],

                        capture_output=True,
                        text=True,
                        check=True
                    )
                    
                    fichiers = result.stdout.splitlines()
                    
                    if not fichiers:
                        messagebox.showinfo("Information", "Aucun fichier de sauvegarde à supprimer.")
                        return
                    
                    # Suppression avec sudo
                    for fichier in fichiers:
                        subprocess.run(["sudo", "rm", fichier], check=True)
                    
                    # Rafraîchir après suppression
                    if hasattr(self.root, 'dashboard') and self.root.dashboard:
                        self.root.after(100, lambda: self.root.dashboard.remplir_fichiers_ftp())
                        self.root.after(100, lambda: self.root.dashboard.update_section(2))
                    messagebox.showinfo(
                        "Succès", 
                        f"Tous les sauvegardes ont été supprimées avec succès."
                    )
                    
                except subprocess.CalledProcessError as e:
                    messagebox.showerror(
                        "Erreur", 
                        f"Échec de la suppression : {e.stderr or 'Permission refusée ou erreur système'}"
                    )
                except Exception as e:
                    messagebox.showerror("Erreur inattendue", f"Une erreur est survenue : {str(e)}")
            
            # Lancement dans un thread séparé
            threading.Thread(target=run_delete).start()




    def enregistrer_serveur_ftp_distant(self):
        top = tk.Toplevel(self)
        top.title("Ajouter un serveur FTP distant")
        top.geometry("400x300")
        top.transient(self)
        top.resizable(False, False)
        top.after(10, lambda: top.grab_set())  # fenêtre modale
        top.configure(bg=self.theme_manager.bg_main)
        self.theme_manager.register_widget(top, 'bg_main')

        container = tk.Frame(top, bg=self.theme_manager.bg_main)
        container.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        self.theme_manager.register_widget(container, 'bg_main')

        # Adresse IP
        tk.Label(container, text="Adresse IP du serveur :", bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main).pack(anchor="w")
        entry_ip = tk.Entry(container)
        self.theme_manager.register_widget(entry_ip, 'bg_main', 'fg_main')
        entry_ip.pack(fill="x")

        # Nom d'utilisateur
        tk.Label(container, text="Nom d'utilisateur :", bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main).pack(anchor="w", pady=(10, 0))
        entry_username = tk.Entry(container)
        self.theme_manager.register_widget(entry_username, 'bg_main', 'fg_main')
        entry_username.pack(fill="x")

        # Mot de passe (optionnel)
        tk.Label(container, text="Mot de passe (optionnel) :", bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main).pack(anchor="w", pady=(10, 0))
        entry_password = tk.Entry(container, show="*")
        self.theme_manager.register_widget(entry_password, 'bg_main', 'fg_main')
        entry_password.pack(fill="x")

        def tester_et_enregistrer():
            ip = entry_ip.get().strip()
            username = entry_username.get().strip()
            password = entry_password.get().strip()

            if not ip or not username:
                messagebox.showerror("Erreur", "IP et nom d'utilisateur sont obligatoires.")
                return

            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            try:
                if password:
                    ssh.connect(ip, username=username, password=password, timeout=5)
                else:
                    ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=5)
                ssh.close()
            except Exception as e:
                messagebox.showerror("Connexion SSH échouée", f"Impossible de se connecter à {ip} : {e}")
                return

            json_path = os.path.join(os.path.dirname(__file__), "..", "files", "serveur_distants.json")
            try:
                if os.path.exists(json_path):
                    with open(json_path, "r") as f:
                        serveurs = json.load(f)
                else:
                    serveurs = []

                # Vérifier si l'IP existe déjà
                if any(s.get("ip") == ip for s in serveurs):
                    messagebox.showwarning("Attention", f"Le serveur avec l'IP {ip} est déjà enregistré.")
                    return

                # Calcul de l'id (max id + 1 ou 1 si liste vide)
                if serveurs:
                    max_id = max(s.get("id", 0) for s in serveurs)
                    new_id = max_id + 1
                else:
                    new_id = 1

                # Construction des données
                data = {"id": new_id, "ip": ip, "username": username}
                # Construction des données
                if password:
                    data["password"] = password  # Stocké en clair


                serveurs.append(data)

                with open(json_path, "w") as f:
                    json.dump(serveurs, f, indent=4)

                messagebox.showinfo("Succès", "Serveur enregistré avec succès.")
                top.destroy()
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur lors de l'enregistrement : {e}")

        # Bouton final
        bouton_enregistrer = tk.Button(container, text="Tester et enregistrer", command=tester_et_enregistrer)
        self.theme_manager.register_widget(bouton_enregistrer, 'bg_secondary', 'fg_main', active_bg='bg_hover', active_fg='fg_main')
        bouton_enregistrer.pack(pady=20)
