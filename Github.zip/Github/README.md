## Téléchargement et installation

Télécharge la dernière version stable sur la page des [releases GitHub](https://github.com/biaoumarsouk/save-config-pro/releases).

Ou directement via ce lien :  
[save-config-pro_1.0-1.deb](https://github.com/biaoumarsouk/save-config-pro/releases/latest/download/save-config-pro_1.0-1.deb)

---

### Installer le paquet sur Ubuntu/Debian

```bash
sudo dpkg -i save-config-pro_1.0-1.deb
sudo apt-get install -f

# Mesprojets
