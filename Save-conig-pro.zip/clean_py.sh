#!/bin/bash

echo "🧹 Suppression des fichiers .py, .pyc et __pycache__..."

# Supprimer tous les .py sauf __init__.py et setup.py (tu peux adapter selon ce que tu veux garder)
find . -name "*.py" ! -name "__init__.py" ! -name "setup.py" -type f -delete

# Supprimer les fichiers compilés Python inutiles
find . -name "*.pyc" -delete

# Supprimer tous les dossiers de cache
find . -name "__pycache__" -type d -exec rm -rf {} +

echo "✅ Nettoyage terminé."
