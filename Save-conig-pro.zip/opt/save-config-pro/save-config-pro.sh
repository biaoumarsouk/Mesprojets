#!/bin/bash
# Lancement de Save Config Pro avec privilèges root

cd /opt/save-config-pro

# Lance le script principal avec sudo
sudo python3 main.py
