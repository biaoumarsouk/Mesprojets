import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import paramiko
import subprocess
from datetime import datetime
import re
import threading


class AskDeleteDialog(tk.Toplevel):
    """
    Une boîte de dialogue personnalisée avec trois options pour la suppression de fichiers.
    """
    def __init__(self, parent, filename, theme_manager):
        super().__init__(parent)
        self.theme_manager = theme_manager
        self.title("Confirmation de Suppression")
        self.result = "cancel" # Valeur par défaut si l'utilisateur ferme la fenêtre

        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        self.configure(bg=theme_manager.bg_main, padx=20, pady=20)
        
        # Message
        message = (
            f"Le fichier '{filename}' existe à la fois sur le serveur local et sur le serveur distant.\n\n"
            "Comment voulez-vous procéder ?"
        )
        tk.Label(self, text=message, bg=theme_manager.bg_main, fg=theme_manager.fg_main, justify="left").pack(pady=(0, 20))

        # Frame pour les boutons
        btn_frame = tk.Frame(self, bg=theme_manager.bg_main)
        btn_frame.pack(fill="x")
        btn_frame.columnconfigure((0, 1, 2), weight=1)

        # Bouton 1 : Supprimer Partout
        btn_all = tk.Button(btn_frame, text="Supprimer Partout", command=lambda: self.set_result("all"))
        btn_all.grid(row=0, column=0, padx=5, sticky="ew")
        self.theme_manager.register_widget(btn_all, 'bg_main', 'fg_main', 'bg_hover')


        # Bouton 2 : Supprimer à Distance Seulement
        btn_remote = tk.Button(btn_frame, text="Distant Uniquement", command=lambda: self.set_result("remote_only"))
        btn_remote.grid(row=0, column=1, padx=5, sticky="ew")
        self.theme_manager.register_widget(btn_remote, 'bg_main', 'fg_main', 'bg_hover')


        # Bouton 3 : Annuler
        btn_cancel = tk.Button(btn_frame, text="Annuler", command=lambda: self.set_result("cancel"))
        btn_cancel.grid(row=0, column=2, padx=5, sticky="ew")
        self.theme_manager.register_widget(btn_cancel, 'bg_main', 'fg_main', 'bg_hover')


        # Attendre que l'utilisateur fasse un choix
        self.wait_window(self)

    def set_result(self, result):
        self.result = result
        self.destroy()


    # À ajouter en haut de votre fichier serveur_distants.py

class AskEmptyDialog(tk.Toplevel):
    """
    Une boîte de dialogue personnalisée avec trois options pour vider un répertoire.
    """
    def __init__(self, parent, message, show_local_option, theme_manager):
        super().__init__(parent)
        self.theme_manager = theme_manager
        self.title("Confirmation de Vidage")
        self.result = "cancel" # Valeur par défaut si l'utilisateur ferme la fenêtre

        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)
        self.configure(bg=theme_manager.bg_main, padx=20, pady=20)
        
        # Message principal
        tk.Label(self, text=message, bg=theme_manager.bg_main, fg=theme_manager.fg_main, justify="left").pack(pady=(0, 20))

        # Frame pour les boutons
        btn_frame = tk.Frame(self, bg=theme_manager.bg_main)
        btn_frame.pack(fill="x")
        
        # Bouton Annuler
        btn_cancel = tk.Button(btn_frame, text="Annuler", command=lambda: self.set_result("cancel"))
        btn_cancel.pack(side="right", padx=5)
        self.theme_manager.register_widget(btn_cancel, 'bg_main', 'fg_main', 'bg_hover')

        # Bouton Vider Distant Seulement
        btn_remote = tk.Button(btn_frame, text="Vider Distant Seulement", command=lambda: self.set_result("remote_only"))
        btn_remote.pack(side="right", padx=5)
        self.theme_manager.register_widget(btn_remote, 'bg_main', 'fg_main', 'bg_hover')


        # Bouton Vider Partout (conditionnel)
        if show_local_option:
            btn_all = tk.Button(btn_frame, text="Vider Partout (Local + Distant)", command=lambda: self.set_result("all"))
            btn_all.pack(side="right", padx=5)
            self.theme_manager.register_widget(btn_all, 'bg_main', 'fg_main', 'bg_hover')

        self.wait_window(self)

    def set_result(self, result):
        self.result = result
        self.destroy()

class ServeursDistantsFrame(tk.Frame):
    def __init__(self, parent, theme_manager, controller=None):
        super().__init__(parent, bg=theme_manager.bg_main)
        self.theme_manager = theme_manager
        self.theme_manager.register_widget(self, 'bg_main')
        self.parent = parent
        self.controller = controller

        self.servers = []
        self.create_widgets()
        self.load_servers()
        self.refresh_data() # Charge et affiche les données initiales

    def create_widgets(self):
        """Crée l'interface graphique de la vue."""
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=0)
        self.grid_columnconfigure(0, weight=1)

        top_frame = tk.Frame(self, bg=self.theme_manager.bg_main)
        top_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=(10, 0))
        top_frame.grid_columnconfigure(0, weight=1)
        
        center_frame = tk.Frame(top_frame, bg=self.theme_manager.bg_main)
        center_frame.grid(row=0, column=0)
        
        title = tk.Label(center_frame, text="\U0001F4BB Système de Gestion des Configurations Réseaux", font=("Arial", 16, "bold"), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main)
        title.pack()
        
        self.mode_label = tk.Label(center_frame, text="Liste des serveurs distants enregistrés", font=("Arial", 14), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main)
        self.mode_label.pack(pady=5)
        
        self.table_frame = tk.Frame(self, bg=self.theme_manager.bg_main)
        self.table_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=10)
        self.table_frame.grid_rowconfigure(0, weight=1)
        self.table_frame.grid_columnconfigure(0, weight=1)
        
        self.columns = ("Adresse IP", "Nom d'utilisateur", "État", "Fichiers")
        self.tree = ttk.Treeview(self.table_frame, columns=self.columns, show="headings")
        for col in self.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", stretch=True)
        
        self.scrollbar = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=self.scrollbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.bind("<Configure>", self.adjust_column_widths)
        self.tree.bind("<Double-1>", self.on_server_click)
        
        self.status_frame = tk.Frame(self, bg=self.theme_manager.bg_main)
        self.status_frame.grid(row=2, column=0, pady=10, sticky="ew")
        
        inner_status = tk.Frame(self.status_frame, bg=self.theme_manager.bg_main)
        inner_status.pack(anchor="center")
        
        self.server_count_var = tk.StringVar(value="Serveurs enregistrés : 0")
        count_label = tk.Label(inner_status, textvariable=self.server_count_var, font=("Arial", 14, "bold"), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main)
        count_label.pack(side="left", padx=20)
        
        status_label = tk.Label(inner_status, text="État du système : OK", font=("Arial", 14, "bold"), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_success)
        status_label.pack(side="left", padx=20)

    def load_servers(self):
        """Charge la liste des serveurs depuis le fichier JSON."""
        json_path = os.path.join(os.path.dirname(__file__), "files", "serveur_distants.json")
        try:
            if os.path.exists(json_path):
                with open(json_path, "r") as f:
                    self.servers = json.load(f)
            else:
                self.servers = []
        except (json.JSONDecodeError, FileNotFoundError):
            self.servers = []
        
        self.server_count_var.set(f"Serveurs enregistrés : {len(self.servers)}")

    def refresh_data(self):
        """
        Recharge les données des serveurs et met à jour le Treeview principal.
        Cette méthode remplace l'ancienne 'insert_data' et peut être appelée pour rafraîchir.
        """
        self.tree.delete(*self.tree.get_children())
        
        for server in self.servers:
            ip = server.get("ip")
            username = server.get("username")
            password = server.get("password", "")
            remote_dir = f"/home/{username}/ftp_backups_distant"
            status = self.check_server_status(ip, username, password)
            file_count = self.get_file_count(ip, username, password, remote_dir)
            self.tree.insert("", "end", values=(ip, username, status, file_count))

        self.server_count_var.set(f"Serveurs enregistrés : {len(self.servers)}")

    def adjust_column_widths(self, event):
        total_width = event.width
        col_count = len(self.columns)
        if col_count > 0:
            for col in self.columns:
                self.tree.column(col, width=total_width // col_count)

    def check_server_status(self, ip, username, password):
        ping_cmd = ["ping", "-c", "1", "-W", "1", ip]
        try:
            if subprocess.run(ping_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0:
                return "❌"
        except Exception:
            return "❌"

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 3}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            return "✔️"
        except Exception:
            return "⚠️"
        finally:
            ssh.close()

    def get_file_count(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 3}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            sftp = ssh.open_sftp()
            files = sftp.listdir(remote_dir)
            count = len([f for f in files if f.lower().endswith((".cfg", ".rsc"))])
            sftp.close()
            ssh.close()
            return count
        except Exception:
            return "?"
    
    # Clique sur chaque serveur
    def on_server_click(self, event):
        selected_item = self.tree.selection()
        if not selected_item: return
        ip_selection = self.tree.item(selected_item[0], "values")[0]
        server_data = next((s for s in self.servers if s.get("ip") == ip_selection), None)
        if server_data:
            self.open_server_detail(server_data)

    # ouverture de détail sur chaque serveur
    def open_server_detail(self, server):
        detail = tk.Toplevel(self)
        detail.title(f"Détails du serveur distant : {server.get('ip', 'N/A')}")
        detail.geometry("900x500")
        detail.transient(self.winfo_toplevel())
        detail.after(100, lambda: detail.grab_set())
        self.theme_manager.register_widget(detail, 'bg_main')

        detail.grid_rowconfigure(1, weight=1)
        detail.grid_columnconfigure(0, weight=1)

        ip, username, password = server.get("ip"), server.get("username"), server.get("password", "")
        remote_dir = f"/home/{username}/ftp_backups_distant"
        server_info = {'ip': ip, 'username': username, 'password': password, 'remote_dir': remote_dir}

        header_frame = tk.Frame(detail, bg=self.theme_manager.bg_main)
        header_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.refresh_server_detail_header(detail, server_info, header_frame)

        files_frame = tk.Frame(detail, bg=self.theme_manager.bg_main)
        files_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        files_frame.grid_rowconfigure(0, weight=1)
        files_frame.grid_columnconfigure(0, weight=1)

        columns = ("Date", "Nom du fichier")
        tree = ttk.Treeview(files_frame, columns=columns, show="headings")
        tree.heading("Date", text="Date de modification"); tree.heading("Nom du fichier", text="Nom du fichier")
        tree.column("Date", width=180, anchor="w"); tree.column("Nom du fichier", anchor="w")
        
        scrollbar = ttk.Scrollbar(files_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        tree.bind("<Double-1>", lambda event: self.open_remote_file_content(event, server_info, tree, header_frame))

        files = self.get_file_list(ip, username, password, remote_dir)
        if files:
            for f, date in sorted(files, key=lambda item: item[1], reverse=True):
                tree.insert("", "end", values=(date, f))
        else:
            tree.insert("", "end", values=("", "Aucun fichier de sauvegarde trouvé."))

        btn_frame = tk.Frame(detail, bg=self.theme_manager.bg_main)
        btn_frame.grid(row=2, column=0, sticky="e", padx=10, pady=10)

        btn_vider = tk.Button(btn_frame, text="🗑️ Vider les fichiers", font=("Arial", 10, "bold"), command=lambda: self.vider_fichiers_serveur(server_info, tree, header_frame))
        btn_vider.pack(side="left", padx=5)
        self.theme_manager.register_widget(btn_vider, 'bg_main', 'fg_main', 'bg_hover')

        btn_supprimer = tk.Button(btn_frame, text="🗑️ Supprimer ce serveur", font=("Arial", 10, "bold"), command=lambda: self.supprimer_serveur(server, detail))
        btn_supprimer.pack(side="left", padx=5)
        self.theme_manager.register_widget(btn_supprimer, 'bg_main', 'fg_main', 'bg_hover')
        
    def refresh_server_detail_header(self, detail_window, server_info, header_frame):
        for widget in header_frame.winfo_children(): widget.destroy()
        ip, username, password, remote_dir = server_info.values()
        status = self.check_server_status(ip, username, password)
        files = self.get_file_list(ip, username, password, remote_dir)
        nb_fichiers = len(files)
        files_hach = self.get_file_hachlist(ip, username, password, remote_dir)
        nb_hach = len(files_hach)
        infos = [
            ("Adresse IP", ip), ("Nom d'utilisateur", username), ("Mot de passe", "********" if password else "Aucun"),
            ("État", status), ("Fichiers de sauvegarde", str(nb_fichiers)), ("Fichiers de hachage", str(nb_hach)),
        ]
        header_frame.grid_columnconfigure((0, 1, 2), weight=1)
        for i, (label_text, value_text) in enumerate(infos):
            f = tk.Frame(header_frame, bg=self.theme_manager.bg_main)
            f.grid(row=i // 3, column=i % 3, padx=5, pady=2, sticky="ew")
            tk.Label(f, text=label_text, font=("Arial", 9, "bold"), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main).pack(anchor="w")
            tk.Label(f, text=value_text, font=("Arial", 9), bg=self.theme_manager.bg_main, fg=self.theme_manager.fg_main).pack(anchor="w")

    def open_remote_file_content(self, event, server_info, file_tree, header_frame):
        selected_item = file_tree.selection()
        if not selected_item: return
        filename = file_tree.item(selected_item[0], "values")[1]
        
        file_window = tk.Toplevel(self)
        file_window.title(f"Contenu de {filename}"); file_window.geometry("700x500")
        file_window.transient(self.winfo_toplevel()); file_window.after(100, lambda: file_window.grab_set())
        self.theme_manager.register_widget(file_window, 'bg_main')
        file_window.rowconfigure(0, weight=1); file_window.columnconfigure(0, weight=1)
        
        text_frame = tk.Frame(file_window, bg=self.theme_manager.bg_main)
        text_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        text_frame.rowconfigure(0, weight=1); text_frame.columnconfigure(0, weight=1)
        scrollbar = ttk.Scrollbar(text_frame); scrollbar.grid(row=0, column=1, sticky="ns")
        text_area = tk.Text(text_frame, wrap="word", bg=self.theme_manager.bg_secondary, fg=self.theme_manager.fg_main, yscrollcommand=scrollbar.set, bd=0, highlightthickness=0)
        text_area.grid(row=0, column=0, sticky="nsew"); scrollbar.config(command=text_area.yview)

        try:
            content = self.read_remote_file(server_info['ip'], server_info['username'], server_info['password'], server_info['remote_dir'], filename)
            text_area.insert("1.0", content if content is not None else f"Erreur: Impossible de lire {filename}.")
        except Exception as e:
            messagebox.showerror("Erreur de lecture", f"Impossible de lire le fichier distant : {e}", parent=file_window)
            file_window.destroy(); return
            
        text_area.config(state="disabled")

        btn_frame = tk.Frame(file_window, bg=self.theme_manager.bg_main)
        btn_frame.grid(row=1, column=0, sticky="e", padx=10, pady=10)
        btn_delete = tk.Button(btn_frame, text="🗑️ Supprimer ce fichier", font=("Arial", 10, "bold"), command=lambda: self.delete_remote_file(server_info, filename, file_window, file_tree, header_frame))
        btn_delete.pack()
        self.theme_manager.register_widget(btn_delete, 'bg_main', 'fg_main', 'bg_hover')

    def read_remote_file(self, ip, username, password, remote_dir, filename):
        remote_path = f"{remote_dir}/{filename}"
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 5}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            
            sftp = ssh.open_sftp()
            with sftp.open(remote_path, 'r') as f:
                content = f.read().decode('utf-8', errors='ignore')
            sftp.close()
            ssh.close()
            return content
        except Exception as e:
            print(f"Erreur de lecture du fichier distant {remote_path}: {e}")
            return None


    def delete_remote_file(self, server_info, filename, parent_window, file_tree, header_frame):
        """
        Supprime un fichier distant en offrant des options avancées si le fichier
        existe aussi localement.
        """
        local_backup_dir = "/home/ftpuser"
        local_filepath = os.path.join(local_backup_dir, filename)
        local_hash_filepath = f"{local_filepath}.sha256"
        
        choice = ""

        if os.path.exists(local_filepath):
            # Le fichier existe localement : on affiche le dialogue à 3 options
            dialog = AskDeleteDialog(parent_window, filename, self.theme_manager)
            choice = dialog.result
            
            if choice == "cancel":
                print("[SUPPRESSION] Opération annulée par l'utilisateur.")
                return
        else:
            # Le fichier n'existe pas localement : simple confirmation Oui/Non
            if messagebox.askyesno("Confirmation", f"Le fichier '{filename}' sera supprimé définitivement du serveur distant.\n\nÊtes-vous sûr de vouloir continuer ?", parent=parent_window):
                choice = "remote_only"
            else:
                return

        # --- Procéder à la suppression en fonction du choix ---
        
        ip, username, password, remote_dir = server_info.values()
        remote_path = f"{remote_dir}/{filename}"
        remote_hash_path = f"{remote_path}.sha256"
        
        try:
            # Étape 1 : Suppression locale si demandée
            if choice == "all":
                print(f"Suppression de la copie locale : {local_filepath}")
                if os.path.exists(local_filepath): os.remove(local_filepath)
                if os.path.exists(local_hash_filepath): os.remove(local_hash_filepath)

            # Étape 2 : Suppression distante
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 5}
            if not password: connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            
            sftp = ssh.open_sftp()
            print(f"Suppression distante de : {remote_path}")
            sftp.remove(remote_path)
            try:
                sftp.remove(remote_hash_path)
                print(f"Suppression du hash distant : {remote_hash_path}")
            except FileNotFoundError:
                pass # C'est normal si le hash n'existe pas
            sftp.close(); ssh.close()
            
            # Message de succès final
            success_message = "Fichier supprimé avec succès "
            if choice == "all":
                success_message += "localement et à distance."
            else:
                success_message += "du serveur distant."
                
            messagebox.showinfo("Succès", success_message, parent=parent_window)
            parent_window.destroy()

            # Rafraîchir toutes les interfaces
            self.refresh_server_detail_header(parent_window.master, server_info, header_frame)
            self.refresh_detail_file_list(file_tree, server_info)
            self.refresh_data()

        except Exception as e:
            messagebox.showerror("Erreur", f"Une erreur est survenue lors de la suppression : {e}", parent=parent_window)


    def get_file_list(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 3}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            sftp = ssh.open_sftp()
            file_list = []
            for f in sftp.listdir_attr(remote_dir):
                filename = f.filename
                if filename.endswith((".cfg", ".rsc")):
                    match = re.search(r"_(\d{4}-\d{2}-\d{2})_(\d{2}-\d{2}-\d{2})", filename)
                    date_str = f"{match.group(1)} {match.group(2).replace('-', ':')}" if match else self.format_date_ts(f.st_mtime)
                    file_list.append((filename, date_str))
            sftp.close()
            ssh.close()
            return file_list
        except Exception as e:
            print("Erreur get_file_list:", e)
            return []
        
        
    def get_file_hachlist(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 3}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            sftp = ssh.open_sftp()
            file_list = []
            for f in sftp.listdir_attr(remote_dir):
                if f.filename.endswith((".cfg.sha256",".rsc.sha256")):
                   file_list.append((f.filename, self.format_date_ts(f.st_mtime)))
            sftp.close()
            ssh.close()
            return file_list
        except Exception as e:
            print("Erreur get_file_list:", e)
            return []
    

    def format_date_ts(self, timestamp):
        try:
            return datetime.fromtimestamp(timestamp).strftime("%d/%m/%Y %H:%M")
        except:
            return "N/A"
    

    # Dans la classe ServeursDistantsFrame

    def vider_fichiers_serveur(self, server_info, file_tree, header_frame):
        """
        Vide le répertoire de sauvegarde sur le serveur distant et propose de
        nettoyer les fichiers locaux, avec une option d'annulation.
        """
        ip, username, password, remote_dir = server_info.values()
        local_dir = "/home/ftpuser"

        try:
            # --- ÉTAPE 1 : Analyser la situation ---
            print("[VIDAGE] Analyse des fichiers avant suppression...")
            local_files = {f for f in os.listdir(local_dir) if f.lower().endswith((".cfg", ".rsc"))} if os.path.exists(local_dir) else set()
            remote_files_with_dates = self.get_file_list(ip, username, password, remote_dir)
            remote_files = {filename for filename, date in remote_files_with_dates}

            if not remote_files:
                messagebox.showinfo("Information", "Le répertoire distant est déjà vide.", parent=file_tree.winfo_toplevel())
                return

            common_files = local_files.intersection(remote_files)
            orphan_files = remote_files - local_files

            # --- ÉTAPE 2 : Construire le message et afficher le dialogue personnalisé ---
            message = f"Vous êtes sur le point de supprimer {len(remote_files)} fichier(s) du serveur distant '{ip}'.\n\n"
            if orphan_files:
                message += f"⚠️ ATTENTION : {len(orphan_files)} fichier(s) n'existent que sur ce serveur distant.\n"
            if common_files:
                message += f"-> {len(common_files)} de ces fichiers existent aussi sur le serveur local.\n\n"
            message += "Comment voulez-vous procéder ?"

            # On n'affiche l'option "Vider Partout" que si c'est pertinent
            show_local_option = bool(common_files)
            
            dialog = AskEmptyDialog(file_tree.winfo_toplevel(), message, show_local_option, self.theme_manager)
            choice = dialog.result

            # --- ÉTAPE 3 : Agir en fonction du choix de l'utilisateur ---
            if choice == "cancel":
                print("[VIDAGE] Opération annulée par l'utilisateur.")
                return

            # Suppression distante (pour 'remote_only' et 'all')
            print("[VIDAGE] Exécution de la suppression sur le serveur distant...")
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 5}
            if not password: connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            ssh.connect(**connect_args)
            cmd = f"rm -f {remote_dir}/*.cfg {remote_dir}/*.rsc {remote_dir}/*.sha256"
            ssh.exec_command(cmd)
            ssh.close()
            
            # Suppression locale (uniquement pour 'all')
            if choice == "all":
                print(f"[VIDAGE] Suppression de {len(common_files)} fichier(s) locaux correspondants...")
                for filename in common_files:
                    try:
                        local_filepath = os.path.join(local_dir, filename)
                        local_hashpath = f"{local_filepath}.sha256"
                        if os.path.exists(local_filepath): os.remove(local_filepath)
                        if os.path.exists(local_hashpath): os.remove(local_hashpath)
                    except OSError as e:
                        print(f"Erreur de suppression locale du fichier {filename}: {e}")
            
            # --- ÉTAPE 4 : Confirmer et rafraîchir ---
            messagebox.showinfo("Succès", "L'opération de vidage a été effectuée avec succès.")
            
            self.refresh_server_detail_header(file_tree.winfo_toplevel(), server_info, header_frame)
            self.refresh_detail_file_list(file_tree, server_info)
            self.refresh_data()

        except Exception as e:
            messagebox.showerror("Erreur", f"Une erreur est survenue lors du vidage des fichiers : {e}")
    
    def supprimer_serveur(self, server, window):
        if not messagebox.askyesno("Confirmation", "Voulez-vous vraiment supprimer ce serveur ?"): return
        try:
            self.load_servers()
            self.servers = [s for s in self.servers if s.get("ip") != server.get("ip")]
            json_path = os.path.join(os.path.dirname(__file__), "files", "serveur_distants.json")
            with open(json_path, "w") as f: json.dump(self.servers, f, indent=4)
            self.refresh_data()
            window.destroy()
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de supprimer le serveur : {e}")


    def refresh_detail_file_list(self, file_tree, server_info):
        """Vide et remplit à nouveau le Treeview des fichiers dans la fenêtre de détails."""
        
        # On vide complètement le Treeview
        file_tree.delete(*file_tree.get_children())
        
        # On récupère la liste fraîche des fichiers depuis le serveur
        ip, username, password, remote_dir = server_info.values()
        files = self.get_file_list(ip, username, password, remote_dir)
        
        if files:
            # On trie par date et on insère les nouvelles données
            for f, date in sorted(files, key=lambda item: item[1], reverse=True):
                file_tree.insert("", "end", values=(date, f))
        else:
            # Si la liste est vide, on affiche un message clair
            file_tree.insert("", "end", values=("", "Aucun fichier de sauvegarde trouvé."))