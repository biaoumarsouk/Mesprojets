import tkinter as tk
from tkinter import messagebox, filedialog
import json
import os
import hashlib
from PIL import Image, ImageTk, ImageDraw, ImageOps
from datetime import datetime

# === Chemins et fichiers ===
DOSSIER_FICHIERS = os.path.join(os.path.dirname(__file__), 'files')
DOSSIER_PROFILS = os.path.join(DOSSIER_FICHIERS, 'profils')
os.makedirs(DOSSIER_FICHIERS, exist_ok=True)
os.makedirs(DOSSIER_PROFILS, exist_ok=True)
FICHIER_HISTORIQUE = os.path.join(DOSSIER_FICHIERS, 'historique_users.json')
FICHIER_UTILISATEURS = os.path.join(DOSSIER_FICHIERS, 'users.json')
if not os.path.exists(FICHIER_UTILISATEURS):
    with open(FICHIER_UTILISATEURS, 'w') as f:
        json.dump({}, f)

def hacher_motdepasse(mdp):
    return hashlib.sha256(mdp.encode()).hexdigest()

def charger_utilisateurs():
    with open(FICHIER_UTILISATEURS, "r") as f:
        return json.load(f)

def sauvegarder_utilisateurs(utilisateurs):
    with open(FICHIER_UTILISATEURS, "w") as f:
        json.dump(utilisateurs, f, indent=4)

def creer_image_cercle(image_pil, size=(100, 100)):
    # Créer un masque circulaire
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, *size), fill=255)
    
    # Redimensionner et rogner l'image pour remplir le cercle
    width, height = size
    # Créer une image carrée en rognant
    if image_pil.width > image_pil.height:
        # Image large - rogner les côtés
        left = (image_pil.width - image_pil.height) / 2
        right = left + image_pil.height
        top = 0
        bottom = image_pil.height
    else:
        # Image haute - rogner le haut et bas
        left = 0
        right = image_pil.width
        top = (image_pil.height - image_pil.width) / 2
        bottom = top + image_pil.width
    
    # Rogner et redimensionner
    image = image_pil.crop((left, top, right, bottom)).resize(size, Image.Resampling.LANCZOS)
    
    # Appliquer le masque
    result = Image.new("RGBA", size)
    result.paste(image, (0, 0), mask)
    
    return ImageTk.PhotoImage(result)

def creer_cercle_vide_avec_icone(size=(100, 100), couleur_bordure="#1c2333", epaisseur=1):
    img = Image.new("RGBA", size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(img)

    # Cercle extérieur
    draw.ellipse((0, 0, size[0]-1, size[1]-1), outline=couleur_bordure, width=epaisseur)

    # Tête (descendue encore un peu)
    draw.ellipse([30, 30, 70, 70], outline=couleur_bordure, width=2)

    # Corps (aussi descendu pour ne pas toucher la tête)
    draw.arc([25, 70, 75, 110], start=180, end=360, fill=couleur_bordure, width=2)

    return ImageTk.PhotoImage(img)



class LoginFrame(tk.Frame):
    def __init__(self, parent, on_login_success):
        super().__init__(parent)
        self.parent = parent
        self.on_login_success = on_login_success

        self.nom_utilisateur = None
        self.chemin_image_profil = None
        self.image_profil_tk = None

        self.configure(bg="white")

        # Layout général : 2 colonnes (50% - 50%)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.left_frame = tk.Frame(self, bg="white")
        self.right_frame = tk.Frame(self, bg="#1c2333")

        self.left_frame.grid(row=0, column=0, sticky="nsew")
        self.right_frame.grid(row=0, column=1, sticky="nsew")

        self.left_frame.grid_rowconfigure(0, weight=1)
        self.left_frame.grid_columnconfigure(0, weight=1)
        self.right_frame.grid_rowconfigure(0, weight=1)
        self.right_frame.grid_columnconfigure(0, weight=1)

        self.container_left_outer = tk.Frame(self.left_frame, bg="white")
        self.container_left_outer.grid(row=0, column=0, sticky="nsew")

        self.left_frame.grid_rowconfigure(0, weight=1)
        self.left_frame.grid_columnconfigure(0, weight=1)

        # On centre le contenu avec une ligne intermédiaire
        self.container_left_outer.grid_rowconfigure(0, weight=1)   # Espace au-dessus
        self.container_left_outer.grid_rowconfigure(1, weight=0)   # Contenu
        self.container_left_outer.grid_rowconfigure(2, weight=1)   # Espace dessous
        self.container_left_outer.grid_columnconfigure(0, weight=1)

        # Le vrai contenu ici :
        self.container_left = tk.Frame(self.container_left_outer, bg="white", width=400)  # largeur fixe 400px
        self.container_left.grid(row=1, column=0, sticky="n", padx=40)  # ajout marge horizontale

        # Empêcher que la Frame se rétrécisse en largeur si le contenu est plus petit
        #self.container_left.grid_propagate(False)


        self.create_login_ui()
        self.create_welcome_ui()

    def create_login_ui(self):
        for widget in self.container_left.winfo_children():
            widget.destroy()

        self.container_left.grid_rowconfigure(99, weight=1)
        self.container_left.grid_columnconfigure(0, weight=1)

        title = tk.Label(self.container_left, text="Se connecter", font=("Arial", 18, "bold"), bg="white")
        title.grid(row=0, column=0, pady=(30, 15), sticky="n")

        def on_entry_click_user(event):
            if self.entry_user.get() == "username":
                self.entry_user.delete(0, "end")

        def on_entry_click_pwd(event):
            if self.entry_pwd.get() == "password":
                self.entry_pwd.delete(0, "end")
                self.entry_pwd.config(show="*")

        def on_focusout_user(event):
            if not self.entry_user.get():
                self.entry_user.insert(0, "username")
                self.entry_pwd.config(show="")
                self.entry_pwd.delete(0, "end")
                self.entry_pwd.insert(0, "password")

        self.entry_user = tk.Entry(self.container_left, font=("Arial", 12), bd=0,
                                   highlightthickness=1, highlightbackground="#aaa",
                                   highlightcolor="#1c2333", relief="solid")
        self.entry_user.insert(0, "username")
        self.entry_user.bind('<FocusIn>', on_entry_click_user)
        self.entry_user.bind('<FocusOut>', on_focusout_user)
        self.entry_user.grid(row=1, column=0, pady=10, ipady=8, ipadx=20, sticky="ew", padx=20)

        self.entry_pwd = tk.Entry(self.container_left, font=("Arial", 12), bd=0,
                                  highlightthickness=1, highlightbackground="#aaa",
                                  highlightcolor="#1c2333", relief="solid")
        self.entry_pwd.insert(0, "password")
        self.entry_pwd.bind('<FocusIn>', on_entry_click_pwd)
        self.entry_pwd.grid(row=2, column=0, pady=10, ipady=8, ipadx=30, sticky="ew", padx=20)

        button_frame = tk.Frame(self.container_left, bg="white")
        button_frame.grid(row=3, column=0, pady=20, sticky="ew", padx=20)
        button_frame.grid_columnconfigure(0, weight=1)

        btn_login = tk.Button(button_frame, text="Se connecter", bg="#1c2333", fg="white",
                              font=("Arial", 12), command=self.verifier_connexion,
                              bd=0, relief="ridge", activebackground="#2c3e50", activeforeground="white")
        btn_login.grid(row=0, column=0, ipady=5, sticky="ew")

        link_signup = tk.Label(self.container_left, text="Vous n'avez pas de compte ? S'inscrire",
                               fg="#1c2333", bg="white", cursor="hand2", font=("Arial", 10))
        link_signup.grid(row=4, column=0, pady=(10, 0))
        link_signup.bind("<Button-1>", lambda e: self.show_signup_ui())

    def choisir_image(self, event=None):
        chemin = filedialog.askopenfilename(
            title="Choisir une image",
            filetypes=[("Images", "*.png *.jpg *.jpeg")]
        )
        if chemin:
            try:
                self.chemin_image_profil = chemin
                img_pil = Image.open(chemin)
                photo = creer_image_cercle(img_pil)
                self.image_profil_tk = photo
                self.canvas_profil.delete("all")
                self.canvas_profil.create_image(50, 50, image=self.image_profil_tk)
                self.canvas_profil.create_oval(1, 1, 99, 99, outline="#1c2333", width=1)
            except Exception as e:
                messagebox.showerror("Erreur", f"Impossible de charger l'image: {str(e)}")

    def create_welcome_ui(self):
        self.right_frame.grid_rowconfigure(0, weight=1)
        self.right_frame.grid_columnconfigure(0, weight=1)

        # Nouveau container verticalement centré
        outer = tk.Frame(self.right_frame, bg="#1c2333")
        outer.grid(row=0, column=0, sticky="nsew")

        outer.grid_rowconfigure(0, weight=1)
        outer.grid_rowconfigure(1, weight=0)
        outer.grid_rowconfigure(2, weight=1)
        outer.grid_columnconfigure(0, weight=1)

        container = tk.Frame(outer, bg="#1c2333")
        container.grid(row=1, column=0, sticky="n")

        # Labels inchangés
        label = tk.Label(container, text="BIENVENUE !", fg="white", bg="#1c2333", font=("Arial", 22, "bold"))
        label.pack(pady=(0, 10))

        labelst = tk.Label(container, 
                        text="Système de Gestion des Configurations Réseaux\nInformatiques",
                        fg="white", bg="#1c2333", font=("Arial", 16, "bold"))
        labelst.pack(pady=(0, 10))

        subtitle = tk.Label(container, text="Se connecter pour continuer", 
                        fg="white", bg="#1c2333", font=("Arial", 12))
        subtitle.pack()


    def show_signup_ui(self):
        for widget in self.container_left.winfo_children():
            widget.destroy()

        self.container_left.grid_columnconfigure(0, weight=1)

        row = 0
        tk.Label(self.container_left, text="S'inscrire", font=("Arial", 18, "bold"), bg="white")\
            .grid(row=row, column=0, pady=(0, 20))

        row += 1
        self.canvas_profil = tk.Canvas(self.container_left, width=100, height=100, bg="white", highlightthickness=0)
        self.canvas_profil.grid(row=row, column=0, pady=(0, 20))
        self.canvas_profil.bind("<Button-1>", self.choisir_image)

        self.img_cercle_vide_icone = creer_cercle_vide_avec_icone()
        self.image_profil_tk = self.img_cercle_vide_icone
        self.canvas_profil.create_image(50, 50, image=self.image_profil_tk)

        def make_placeholder(entry, placeholder, is_password=False):
            def on_entry_click(event):
                if entry.get() == placeholder:
                    entry.delete(0, "end")
                    if is_password:
                        entry.config(show="*")
            def on_focusout(event):
                if not entry.get():
                    entry.insert(0, placeholder)
                    if is_password:
                        entry.config(show="")
            entry.insert(0, placeholder)
            entry.bind('<FocusIn>', on_entry_click)
            entry.bind('<FocusOut>', on_focusout)
            if is_password:
                entry.config(show="")

        champs = [
            ("Nom", False),
            ("Prénom", False),
            ("username", False),
            ("password", True),
            ("confirmer le mot de passe", True)
        ]

        entries = []
        for text, is_pwd in champs:
            row += 1
            entry = tk.Entry(self.container_left, font=("Arial", 12), bd=0,
                             highlightthickness=1, highlightbackground="#aaa",
                             highlightcolor="#1c2333", relief="solid")
            make_placeholder(entry, text, is_pwd)
            entry.grid(row=row, column=0, pady=5, ipady=8, ipadx=30, sticky="ew", padx=20)
            entries.append(entry)

        self.entry_nom, self.entry_prenom, self.entry_new_user, self.entry_new_pwd, self.entry_confirm_pwd = entries

        row += 1
        button_frame = tk.Frame(self.container_left, bg="white")
        button_frame.grid(row=row, column=0, pady=20, sticky="ew", padx=20)
        button_frame.grid_columnconfigure(0, weight=1)

        btn_create = tk.Button(button_frame, text="Créer un compte", bg="#1c2333",
                               fg="white", font=("Arial", 12), command=self.creer_compte,
                               bd=0, relief="ridge", activebackground="#2c3e50", activeforeground="white")
        btn_create.grid(row=0, column=0, ipady=5, sticky="ew")

        row += 1
        link_back = tk.Label(self.container_left, text="Vous avez déjà un compte ? Se connecter",
                             fg="#1c2333", bg="white", cursor="hand2", font=("Arial", 10))
        link_back.grid(row=row, column=0)
        link_back.bind("<Button-1>", lambda e: self.reset_login_ui())


    def reset_login_ui(self):
        for widget in self.container_left.winfo_children():
            widget.destroy()
        self.create_login_ui()

    def enregistrer_connexion(self, nom_utilisateur, connect=True, tentative=False):
        historique = []

        if os.path.exists(FICHIER_HISTORIQUE):
            with open(FICHIER_HISTORIQUE, "r") as f:
                try:
                    historique = json.load(f)
                except json.JSONDecodeError:
                    historique = []

        nouvelle_entree = {
            "utilisateur": nom_utilisateur,
            "date_connexion": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "connect": connect,
            "tentative": tentative,
        }

        historique.append(nouvelle_entree)

        with open(FICHIER_HISTORIQUE, "w") as f:
            json.dump(historique, f, indent=4)
            
    def verifier_connexion(self):
        utilisateurs = charger_utilisateurs()
        nom = self.entry_user.get()
        mdp = self.entry_pwd.get()

        if nom == "username" or mdp == "password":
            messagebox.showerror("Erreur", "Veuillez saisir vos identifiants")
            self.enregistrer_connexion(nom_utilisateur=nom, connect=False, tentative=True)
            return

        mdp_hache = hacher_motdepasse(mdp)

        if nom in utilisateurs:
            if utilisateurs[nom]["password"] == mdp_hache:
                if not utilisateurs[nom].get("status", False):
                    messagebox.showerror("Erreur", "La connexion à ce compte n'est pas autorisée")
                    self.enregistrer_connexion(nom_utilisateur=nom, connect=False, tentative=True)
                    return

                # Connexion réussie
                utilisateurs[nom]["connexion"] = True
                utilisateurs[nom]["derniere_connexion"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                sauvegarder_utilisateurs(utilisateurs)

                self.enregistrer_connexion(nom_utilisateur=nom, connect=True, tentative=False)
                self.nom_utilisateur = nom
                self.on_login_success(nom)
            else:
                messagebox.showerror("Erreur", "Mot de passe incorrect")
                self.enregistrer_connexion(nom_utilisateur=nom, connect=False, tentative=True)
        else:
            messagebox.showerror("Erreur", "Nom d'utilisateur incorrect")
            self.enregistrer_connexion(nom_utilisateur=nom, connect=False, tentative=True)




    def creer_compte(self):
        utilisateurs = charger_utilisateurs()

        nom = self.entry_nom.get().strip()
        prenom = self.entry_prenom.get().strip()
        username = self.entry_new_user.get().strip()
        mdp = self.entry_new_pwd.get().strip()
        confirm_mdp = self.entry_confirm_pwd.get().strip()

        # Validation des champs vides ou non remplis
        if (nom == "" or nom == "Nom" or
            prenom == "" or prenom == "Prénom" or
            username == "" or username == "username" or
            mdp == "" or mdp == "password" or
            confirm_mdp == "" or confirm_mdp == "confirmer le mot de passe"):
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return

        # Validation de l'identifiant
        if username in utilisateurs:
            messagebox.showerror("Erreur", "Ce nom d'utilisateur existe déjà.")
            return
        if len(username) < 8:
            messagebox.showerror("Erreur", "L'identifiant doit contenir au moins 8 caractères.")
            return
        if not username.islower():
            messagebox.showerror("Erreur", "L'identifiant doit contenir uniquement des lettres minuscules.")
            return
        if not username.isalpha():
            messagebox.showerror("Erreur", "L'identifiant ne doit contenir que des lettres (pas de chiffres ni symboles).")
            return

        # Validation du mot de passe
        if len(mdp) < 8:
            messagebox.showerror("Erreur", "Le mot de passe doit contenir au moins 8 caractères.")
            return
        if not any(c.isupper() for c in mdp):
            messagebox.showerror("Erreur", "Le mot de passe doit contenir au moins une lettre majuscule.")
            return
        if not any(c.isdigit() for c in mdp):
            messagebox.showerror("Erreur", "Le mot de passe doit contenir au moins un chiffre.")
            return
        if not any(c in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/\\`~" for c in mdp):
            messagebox.showerror("Erreur", "Le mot de passe doit contenir au moins un symbole (ex: ! @ # $ etc.).")
            return

        # Vérification de la confirmation du mot de passe
        if mdp != confirm_mdp:
            messagebox.showerror("Erreur", "Les mots de passe ne correspondent pas.")
            return

        # Gestion de la photo de profil
        photo_fichier = "default.png"
        if self.chemin_image_profil:
            ext = os.path.splitext(self.chemin_image_profil)[1]
            photo_fichier = f"{username}{ext}"
            chemin_destination = os.path.join(DOSSIER_PROFILS, photo_fichier)
            try:
                with open(self.chemin_image_profil, 'rb') as src, open(chemin_destination, 'wb') as dst:
                    dst.write(src.read())
            except Exception as e:
                messagebox.showwarning("Avertissement", f"Erreur lors de la copie de l'image : {str(e)}")

        # Création du compte utilisateur
        utilisateurs[username] = {
            "nom": nom,
            "prenom": prenom,
            "password": hacher_motdepasse(mdp),
            "status": False,
            "role": "user",
            "connexion": False,
            "derniere_connexion": None,
            "date_creation": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "photo_profil": photo_fichier
        }

        sauvegarder_utilisateurs(utilisateurs)
        messagebox.showinfo("Succès", "Compte créé avec succès !")
        self.reset_login_ui()
