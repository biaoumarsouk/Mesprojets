import os
import shutil
import json
import platform
import subprocess
from datetime import datetime
import psutil
import struct
import socket
import paramiko

# --- Fonctions utilitaires (identiques aux autres modules) ---

def get_local_ip_in_subnet(subnet_cidr, all_interfaces):
    try:
        subnet_ip, subnet_mask = subnet_cidr.split('/')
        subnet_int = struct.unpack("!I", socket.inet_aton(subnet_ip))[0]
        mask_int = (0xFFFFFFFF << (32 - int(subnet_mask))) & 0xFFFFFFFF
    except (ValueError, socket.error): return None
    def ip_to_int(ip): return struct.unpack("!I", socket.inet_aton(ip))[0]
    for addrs in all_interfaces.values():
        for addr in addrs:
            if addr.family == socket.AF_INET:
                try:
                    if (ip_to_int(addr.address) & mask_int) == (subnet_int & mask_int): return addr.address
                except socket.error: continue
    return None

def get_subnet_for_ip(ip, subnets):
    try:
        ip_int = struct.unpack("!I", socket.inet_aton(ip))[0]
        for subnet in subnets:
            subnet_ip, subnet_mask = subnet.split('/')
            subnet_int = struct.unpack("!I", socket.inet_aton(subnet_ip))[0]
            mask_int = (0xFFFFFFFF << (32 - int(subnet_mask))) & 0xFFFFFFFF
            if (ip_int & mask_int) == (subnet_int & mask_int): return subnet
    except (ValueError, socket.error): return None
    return None

def is_reachable(ip):
    param = "-n" if platform.system().lower() == "windows" else "-c"
    command = ['ping', param, '1', '-W', '1', ip]
    try: return subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    except Exception: return False

def test_ssh_connection(ip, username, password, timeout=3):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=ip, username=username, password=password, timeout=timeout, allow_agent=False, look_for_keys=False)
        client.close()
        return True
    except Exception: return False

def get_mac_from_arp(ip):
    try:
        output = subprocess.check_output(['arp', '-n', ip], text=True, stderr=subprocess.DEVNULL)
        for line in output.splitlines():
            if ip in line:
                parts = line.split()
                for part in parts:
                    if ':' in part and len(part) == 17: return part.lower()
    except Exception: pass
    return None

# --- Fonction principale du module ---

def run_fortinet_backup():
    """
    Génère les fichiers Ansible et exécute la sauvegarde pour les équipements Fortinet.
    Retourne TOUJOURS un tuple (bool, str).
    """
    print("--- [BACKUP TASK] Démarrage de la tâche de sauvegarde Fortinet ---")
    
    try:
        # --- [ÉTAPE 1] Chargement des configurations ---
        script_dir = os.path.dirname(os.path.abspath(__file__))
        networks_path = os.path.join(script_dir, '..', 'files', 'networks.json')
        json_file_fortinet = os.path.join(script_dir, '..', 'files', 'fortinet_save.json')

        with open(networks_path, 'r') as f:
            subnets_config = json.load(f)
        with open(json_file_fortinet, 'r') as f:
            equipments_original = json.load(f)

        all_interfaces = psutil.net_if_addrs()
        subnet_ftp_map = {s: get_local_ip_in_subnet(s, all_interfaces) for s in subnets_config}
        subnet_ftp_map = {k: v for k, v in subnet_ftp_map.items() if v}

        if not subnet_ftp_map:
            return (False, "Impossible de détecter les IPs locales dans les sous-réseaux.")

        # --- [ÉTAPE 2] Validation des équipements ---
        valid_equipments = []
        for eq in equipments_original:
            ip = eq.get('ip')
            if not ip or not is_reachable(ip):
                eq['sauvegarde'] = False; continue
            
            expected_mac = eq.get('mac', '').lower().replace("-", ":")
            actual_mac = get_mac_from_arp(ip)
            if not actual_mac or actual_mac != expected_mac:
                eq['sauvegarde'] = False; continue
            
            subprocess.run(f"ssh-keygen -R {ip}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            if not test_ssh_connection(ip, eq.get('credentials', {}).get('username'), eq.get('credentials', {}).get('password')):
                eq['sauvegarde'] = False; continue

            # --- CORRECTION APPLIQUÉE ICI ---
            # L'équipement est valide, on met à jour ses informations
            eq['status'] = True
            eq['sauvegarde'] = True
            subnet_cidr = get_subnet_for_ip(ip, subnet_ftp_map.keys())
            if subnet_cidr:
                eq['subnet'] = subnet_cidr
                eq['ftp_server'] = subnet_ftp_map[subnet_cidr]
            
            valid_equipments.append(eq)
        
        with open(json_file_fortinet, 'w') as f:
            json.dump(equipments_original, f, indent=4)
        
        if not valid_equipments:
            return (True, "Aucun équipement Fortinet valide à sauvegarder.")

        # --- [ÉTAPE 3] Création des fichiers Ansible ---
        print(f"   -> {len(valid_equipments)} équipement(s) valide(s) trouvé(s). Génération des fichiers...")
        backup_parent_dir = os.path.join(script_dir, '..', 'files', 'backup_fortinet')
        if os.path.exists(backup_parent_dir):
            shutil.rmtree(backup_parent_dir)
        os.makedirs(backup_parent_dir)
        
        # Grouper les équipements par serveur FTP
        equipments_by_ftp_server = {}
        for eq in valid_equipments:
            ftp_server = eq.get('ftp_server')
            if ftp_server:
                if ftp_server not in equipments_by_ftp_server:
                    equipments_by_ftp_server[ftp_server] = []
                equipments_by_ftp_server[ftp_server].append(eq)

        current_date = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        
        for ftp_ip, eq_list in equipments_by_ftp_server.items():
            if not eq_list: continue

            backup_dir = os.path.join(backup_parent_dir, f'backup_fortinet_{ftp_ip.replace(".", "_")}')
            os.makedirs(backup_dir)

            with open(os.path.join(backup_dir, 'inventory.ini'), 'w') as f:
                f.write(f"# Fichier généré le {current_date}\n[fortinet]\n")
                for eq in eq_list:
                    f.write(
                        f"{eq['mac'].replace(':', '-')} ansible_host={eq['ip']} "
                        f"ansible_user={eq['credentials']['username']} "
                        f"ansible_ssh_pass={eq['credentials']['password']} "
                        "ansible_connection=ssh\n"
                    )

            with open(os.path.join(backup_dir, 'ansible.cfg'), 'w') as f:
                f.write(f"# Configuration générée le {current_date}\n"
                        "[defaults]\n"
                        "inventory = inventory.ini\n"
                        "host_key_checking = False\n"
                        "timeout = 60\n"
                        "gathering = explicit\n"
                        "deprecation_warnings = False\n\n"
                        "[ssh_connection]\n"
                        "ssh_args = -o KexAlgorithms=+diffie-hellman-group14-sha1 -o HostKeyAlgorithms=+ssh-rsa\n")
            
            playbook_content = f"""---
# Playbook FortiGate - Généré le {current_date}
- name: Sauvegarder la configuration FortiGate via FTP
  hosts: fortinet
  gather_facts: no
  tasks:
    - name: Backup config via raw command
      ansible.builtin.raw: >
        execute backup config ftp fortinet_{{{{ inventory_hostname }}}}_{{{{ lookup('pipe', 'date +%Y-%m-%d_%H-%M-%S') }}}}.cfg {ftp_ip} ftpuser Saveconfig57
"""
            with open(os.path.join(backup_dir, 'backup_fortinet_ftp.yml'), 'w') as f:
                f.write(playbook_content)


    except FileNotFoundError as e:
        msg = f"Fichier de configuration manquant : {os.path.basename(e.filename)}"
        print(f"ERREUR: {msg}")
        return (False, msg)
    except Exception as e:
        msg = f"Erreur inattendue lors de la sauvegarde Fortinet : {type(e).__name__} - {e}"
        print(f"ERREUR: {msg}")
        return (False, msg)

    return (True, f"{len(valid_equipments)} équipement(s) Fortinet sauvegardé(s) avec succès.")
