import os
import time
import shlex
import subprocess
import paramiko
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from tkinter import messagebox

class SyncHandler(FileSystemEventHandler):
    """
    Gestionnaire d'événements pour Watchdog. Déclenche la synchronisation
    lorsqu'un fichier est modifié dans le répertoire local.
    """
    def __init__(self, local_dir, servers):
        self.local_dir = local_dir
        self.servers = servers
        self.sync_en_cours = False
        self.use_ssh_key_for = set()

    def on_any_event(self, event):
        if event.is_directory:
            return

        if self.sync_en_cours:
            print("[⏳] Une synchronisation est déjà en cours. Événement ignoré.")
            return

        print(f"[🔔] Modification détectée : {event.src_path}")
        self.sync_en_cours = True
        try:
            for server in self.servers:
                self.sync_to_remote(server)
        finally:
            self.sync_en_cours = False

    def sync_to_remote(self, server):
        """Synchronise les fichiers vers un serveur distant via rsync."""
        ip = server["ip"]
        username = server["username"]
        password = server.get("password", "")
        remote_path = server["remote_dir"]
        ssh_key = os.path.expanduser("~/.ssh/id_rsa")

        if ip in self.use_ssh_key_for:
            rsync_cmd_key = (
                f"rsync -az --delete "
                f"-e 'ssh -i {ssh_key} -o StrictHostKeyChecking=no -o PreferredAuthentications=publickey' "
                f"{shlex.quote(self.local_dir)}/ {username}@{ip}:{shlex.quote(remote_path)}/"
            )
            print(f"[🔁] Tentative de synchronisation vers {ip} (clé SSH)...")
            result = subprocess.run(rsync_cmd_key, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"[✅] Synchronisation réussie vers {ip} avec clé SSH.")
                return
            else:
                print(f"[⚠️] Clé SSH refusée pour {ip}, basculement vers mot de passe.")
                self.use_ssh_key_for.remove(ip)

        rsync_cmd_pw = (
            f"sshpass -p {shlex.quote(password)} "
            f"rsync -az --delete -e 'ssh -o StrictHostKeyChecking=no' "
            f"{shlex.quote(self.local_dir)}/ {username}@{ip}:{shlex.quote(remote_path)}/"
        )
        print(f"[🔁] Tentative de synchronisation vers {ip} (mot de passe)...")
        result = subprocess.run(rsync_cmd_pw, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"[✅] Synchronisation réussie vers {ip} avec mot de passe.")
        else:
            print(f"[❌] Échec de la synchronisation vers {ip} :\n{result.stderr.strip()}")

def verifier_dependances_distantes(ssh):
    """
    Vérifie si 'rsync' est installé sur le serveur distant.
    Retourne True si c'est le cas, False sinon.
    """
    print(f"[🌐] Vérification de la présence de 'rsync' sur {ssh.get_transport().getpeername()[0]}...")
    try:
        stdin, stdout, stderr = ssh.exec_command("command -v rsync")
        exit_status = stdout.channel.recv_exit_status()
        if exit_status == 0:
            print("[✅] 'rsync' est bien installé sur le serveur distant.")
            return True
        else:
            print("[❌] ERREUR : 'rsync' n'est pas installé sur le serveur distant.")
            return False
    except Exception as e:
        print(f"[❌] Erreur lors de la vérification des dépendances distantes : {e}")
        return False

def charger_serveurs(json_path):
    """
    Charge la liste des serveurs depuis un fichier JSON.
    """
    try:
        with open(json_path, "r") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"[⚠️] Impossible de lire le fichier des serveurs ({e}). On suppose qu'il est vide.")
        return []

def lancer_synchronisation_multi_serveurs():
    """
    Fonction principale qui orchestre la configuration et le lancement de la synchronisation.
    """
    print("=== Démarrage du module de Synchronisation Automatique ===")

    json_path = os.path.join(os.path.dirname(__file__), "..", "files", "serveur_distants.json")
    serveurs = charger_serveurs(json_path)

    if not serveurs:
        print("[ℹ️] Aucun serveur distant n'est enregistré. La synchronisation est désactivée.")
        messagebox.showinfo(
            "Synchronisation non active", 
            "Aucun serveur distant n'est enregistré pour la synchronisation automatique."
        )
        return None

    local_dir = "/home/ftpuser"
    if not os.path.exists(local_dir):
        try:
            os.makedirs(local_dir)
            subprocess.run(['sudo', 'chown', 'ftpuser:ftpuser', local_dir], check=True)
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de créer le dossier local {local_dir}:\n{e}")
            return None
            
    print(f"[📁] Dossier local surveillé : {local_dir}")

    serveurs_valides = []
    
    for server in serveurs:
        ip = server.get("ip")
        username = server.get("username")
        password = server.get("password", "")
        if not ip or not username:
            continue

        server["remote_dir"] = f"/home/{username}/ftp_backups_distant"
        
        print(f"[🔗] Configuration et vérification de {ip}...")
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        try:
            connect_args = {'hostname': ip, 'username': username, 'password': password, 'timeout': 10}
            if not password:
                connect_args['key_filename'] = os.path.expanduser("~/.ssh/id_rsa")
            
            ssh.connect(**connect_args)
            
            if not verifier_dependances_distantes(ssh):
                messagebox.showwarning(
                    "Dépendance Manquante", 
                    f"Le serveur distant {ip} n'a pas 'rsync' d'installé.\n\n"
                    f"Veuillez l'installer avec 'sudo apt install rsync'.\n"
                    f"Ce serveur sera ignoré pour la synchronisation."
                )
                continue

            ssh.exec_command(f"mkdir -p {shlex.quote(server['remote_dir'])}")
            print(f"[✅] Serveur {ip} est prêt pour la synchronisation.")
            serveurs_valides.append(server)

        except Exception as e:
            print(f"[❌] Échec de la configuration pour {ip} : {e}. Ce serveur sera ignoré.")
        finally:
            ssh.close()

    if not serveurs_valides:
        print("[ℹ️] Aucun serveur distant n'a pu être configuré. Synchronisation annulée.")
        messagebox.showwarning(
            "Synchronisation Annulée", 
            "Aucun des serveurs distants enregistrés n'est accessible ou correctement configuré."
        )
        return None
        
    handler = SyncHandler(local_dir, serveurs_valides)
    
    print(f"[🚀] Lancement de la synchronisation initiale vers {len(serveurs_valides)} serveur(s)...")
    for server in serveurs_valides:
        handler.sync_to_remote(server)

    print("[👀] Démarrage de la surveillance des modifications locales...")
    observer = Observer()
    observer.schedule(handler, local_dir, recursive=True)
    observer.start()

    return observer