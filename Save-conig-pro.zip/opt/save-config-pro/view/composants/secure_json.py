import json
import os
import subprocess

# On garde une référence aux fonctions originales avant de les remplacer.
# Pour pouvoir les appeler depuis nos fonctions.
_original_json_load = json.load
_original_json_dump = json.dump

# Le chemin absolu vers la clé de chiffrement.
# C'est une constante, donc on la définit en majuscules.
KEY_FILE = "/etc/save-config-pro/secret.key"

# Liste de tous les noms de fichiers JSON que l'on souhaite protéger.
# Notre code n'agira que sur les fichiers dont le nom est dans cette liste.
ENCRYPTED_FILES = [
    'users.json', 
    'cisco_save.json', 
    'mikrotik_save.json',
    'fortinet_save.json', 
    'huawei_save.json', 
    'juniper_save.json',
    'networks.json', 
    'sauvegarde.json', 
    'restauration.json',
    'operation_sauvegarde.json', 
    'historique_users.json', 
    'serveur_distants.json'
]

# --- CORRECTION APPLIQUÉE ICI ---
# Liste des fichiers qui, à leur racine, sont des listes [...]
# et non des dictionnaires {...}. C'est crucial pour retourner le bon
# type de données par défaut en cas d'erreur.
LIST_BASED_FILES = [
    'cisco_save.json', 
    'mikrotik_save.json',
    'fortinet_save.json',
    'huawei_save.json',
    'juniper_save.json',
    'networks.json',
    'restauration.json',
    'operation_sauvegarde.json',
    'historique_users.json'
]

# Fonctions de chiffrement/déchiffrement de bas niveau.
# Le préfixe '_' indique que ce sont des fonctions "privées" à ce module.

def _encrypt(plaintext_data):
    """Chiffre une chaîne de caractères en utilisant OpenSSL."""
    if not os.path.exists(KEY_FILE):
        raise FileNotFoundError(f"Clé de chiffrement introuvable à {KEY_FILE}")
    try:
        command = ['openssl', 'enc', '-aes-256-cbc', '-salt', '-a', '-pass', f'file:{KEY_FILE}']
        process = subprocess.run(
            command,
            input=plaintext_data,
            capture_output=True,
            text=True,
            check=True
        )
        return process.stdout
    except subprocess.CalledProcessError as e:
        raise IOError(f"Erreur OpenSSL lors du chiffrement : {e.stderr.strip()}")

def _decrypt(encrypted_text):
    """Déchiffre une chaîne de caractères chiffrée avec OpenSSL."""
    if not os.path.exists(KEY_FILE):
        raise FileNotFoundError(f"Clé de chiffrement introuvable à {KEY_FILE}")
    if not encrypted_text:
        return ""
    try:
        command = ['openssl', 'enc', '-d', '-aes-256-cbc', '-a', '-pass', f'file:{KEY_FILE}']
        process = subprocess.run(
            command,
            input=encrypted_text,
            capture_output=True,
            text=True,
            check=True
        )
        return process.stdout
    except subprocess.CalledProcessError as e:
        raise IOError(f"Erreur OpenSSL lors du déchiffrement : {e.stderr.strip()}")

# --- Nos nouvelles fonctions qui vont remplacer celles de 'json' ---

def secure_dump(obj, fp, **kwargs):
    """
    Notre version de json.dump.
    Vérifie si le fichier doit être chiffré avant de l'écrire.
    'fp' est l'objet fichier ouvert en écriture.
    """
    file_name = os.path.basename(fp.name)
    
    if file_name in ENCRYPTED_FILES:
        # Le fichier est sensible : on chiffre.
        json_string = json.dumps(obj, **kwargs)
        encrypted_content = _encrypt(json_string)
        fp.write(encrypted_content)
    else:
        # Le fichier n'est pas dans la liste : on utilise la fonction originale.
        _original_json_dump(obj, fp, **kwargs)

def secure_load(fp, **kwargs):
    """
    Notre version de json.load.
    Vérifie si le fichier doit être déchiffré avant de le lire.
    Retourne une liste ou un dictionnaire vide en cas d'erreur.
    """
    file_name = os.path.basename(fp.name)
    
    if file_name in ENCRYPTED_FILES:
        # --- LOGIQUE CORRIGÉE ---
        # 1. Déterminer la valeur de retour par défaut en cas d'échec.
        default_return_value = [] if file_name in LIST_BASED_FILES else {}
        
        encrypted_content = fp.read()
        
        # 2. Si le fichier est vide, retourner la valeur par défaut appropriée.
        if not encrypted_content:
            return default_return_value
        
        try:
            # 3. Essayer de déchiffrer et de parser le JSON.
            decrypted_json_str = _decrypt(encrypted_content)
            return json.loads(decrypted_json_str, **kwargs)
        except (IOError, json.JSONDecodeError) as e:
            # 4. En cas d'échec, afficher un avertissement et retourner la valeur par défaut.
            return default_return_value
    else:
        # Le fichier n'est pas sensible : on utilise la fonction originale.
        return _original_json_load(fp, **kwargs)

def patch_json_module():
    """
    Fonction principale qui remplace les fonctions du module json
    par nos versions sécurisées. Doit être appelée une seule fois au démarrage.
    """
    # On vérifie si le patch a déjà été appliqué pour éviter de le faire plusieurs fois.
    if json.load == secure_load:
        return
        
    json.load = secure_load
    json.dump = secure_dump