import tkinter as tk
from tkinter import ttk

class AideLogiciel(tk.Frame):
    def __init__(self, parent, theme_manager):
        super().__init__(parent, bg=theme_manager.bg_main)
        self.theme_manager = theme_manager
        self.theme_manager.register_widget(self, 'bg_main')

        self.pack(fill="both", expand=True)

        # Canvas + Scrollbar
        canvas = tk.Canvas(self, bg=self.theme_manager.bg_main, highlightthickness=0)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.configure(yscrollcommand=scrollbar.set)

        # Frame interne scrollable
        self.inner_frame = tk.Frame(canvas, bg=self.theme_manager.bg_main)
        self.inner_frame_id = canvas.create_window((0, 0), window=self.inner_frame, anchor="nw")

        # Scroll dynamique
        self.inner_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(self.inner_frame_id, width=e.width))

        self.theme_manager.register_widget(canvas, 'bg_main')
        self.theme_manager.register_widget(self.inner_frame, 'bg_main')


        # Création des groupes
        self.create_group("Etapes de sauvegarde", [
            "1. Choisir le(s) réseau(x) à scanner parmi les réseaux disponibles.",
            "2. Effectuer le scan des réseaux sélectionnés.",
            "3. Sélectionner le(s) équipement(s) à sauvegarder.",
            "4. Entrer leurs identifiants d’accès.",
            "5. Accéder au module de planification.",
            "6. Créer une sauvegarde.",
            "7. Les équipements avec identifiants d'accès corrects seront validés.",
            "8. Définir l'intervalle de temps pour le cycle de sauvegarde.",
            "9. Cliquer sur le bouton démarrerou central pour démarrer.",
            "10. Vérifier les résultats dans le module sauvegarde.",
            "11. Vous pouvez visualiser les fichiers sauvegardés.",
            "12. Cliquer sur le bouton arreter ou central pour arreter.",
        ])


        self.create_group("Etapes de restauration", [
            "1. Accéder au module sauvegarde.",
            "2. Choisir un equipement.",
            "3. Cliquer sur un fichier de configuration.",
            "2. Vérifier l’équipement cible.",
            "3. Cliquer sur restaurer.",
            "4. Attendre le message de confirmation de restauration."
        ])
        
        self.create_group("Tableau de bord", [
            "1. Répartition des équipements enregistrés par constructeur.",
            "2. Liste des équipements en cours de sauvegarde avec leur état.",
            "3. Compte à rebours avant la prochaine sauvegarde automatique.",
            "4. État des outils du système (FTP, Ansible, etc.).",
            "5. Espace de stockage utilisé pour les fichiers sauvegardés.",
            "6. Liste détaillée des fichiers de configuration sauvegardés.",
            "7. Statistiques globales : réseaux détectés, équipements, fichiers, pannes."
        ])


    def create_group(self, title, steps, is_etape=True):
        group_frame = tk.LabelFrame(
            self.inner_frame,
            text=title,
            font=("Arial", 14, "bold"),
            bg=self.theme_manager.bg_main,
            fg=self.theme_manager.fg_main,
            bd=2,
            relief="groove",
            padx=10,
            pady=10
        )
        # Prend toute la largeur disponible du parent (inner_frame)
        group_frame.pack(fill="x", pady=10, padx=20)
        self.theme_manager.register_widget(group_frame, 'bg_main', 'fg_main')

        if is_etape:
            max_per_row = 3
            # Frame interne pour la grille
            row_frame = tk.Frame(group_frame, bg=self.theme_manager.bg_main)
            row_frame.pack(fill="x")
            self.theme_manager.register_widget(row_frame, 'bg_main', 'fg_main')

            for index, step in enumerate(steps):
                step_frame = tk.Frame(row_frame, bg=self.theme_manager.bg_main)
                step_frame.grid(row=index // max_per_row, column=index % max_per_row, padx=5, pady=5, sticky="nsew")

                # Séparer le numéro et le texte
                # Extrait numéro en début, par ex "1." ou "2."
                import re
                match = re.match(r"(\d+\.?)\s*(.*)", step)
                if match:
                    numero, texte = match.group(1), match.group(2)
                else:
                    numero, texte = "", step

                label_numero = tk.Label(
                    step_frame,
                    text=numero,
                    bg=self.theme_manager.bg_main,
                    fg=self.theme_manager.fg_main,
                    font=("Arial", 14, "bold"),
                    width=3,  # largeur fixe pour aligner les numéros
                    anchor="w"
                )
                label_numero.grid(row=0, column=0, sticky="nw", padx=(30, 0), pady=10)

                label_texte = tk.Label(
                    step_frame,
                    text=texte,
                    wraplength=220,
                    justify="left",
                    bg=self.theme_manager.bg_main,
                    fg=self.theme_manager.fg_main,
                    font=("Arial", 12)
                )
                label_texte.grid(row=0, column=1, sticky="nw", padx=(5, 10), pady=10)

                self.theme_manager.register_widget(step_frame, 'bg_main')
                self.theme_manager.register_widget(label_numero, 'bg_main', 'fg_main')
                self.theme_manager.register_widget(label_texte, 'bg_main', 'fg_main')

            # Configurer le poids des colonnes pour que la grille occupe toute la largeur
            for i in range(max_per_row):
                row_frame.grid_columnconfigure(i, weight=1)



import tkinter as tk
from tkinter import ttk

class FonctionnaliteSysteme(tk.Frame):
    def __init__(self, parent, theme_manager):
        super().__init__(parent, bg=theme_manager.bg_main)
        self.theme_manager = theme_manager
        self.theme_manager.register_widget(self, 'bg_main')

        self.pack(fill="both", expand=True)

        # Création d'un Canvas et d'une Scrollbar pour le défilement
        canvas = tk.Canvas(self, bg=self.theme_manager.bg_main, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        
        # Le frame interne qui contiendra tout le contenu et qui sera scrollable
        self.inner_frame = tk.Frame(canvas, bg=self.theme_manager.bg_main)

        # Placement des widgets
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Configuration de la liaison entre canvas et scrollbar
        canvas.configure(yscrollcommand=scrollbar.set)
        inner_frame_id = canvas.create_window((0, 0), window=self.inner_frame, anchor="nw")

        # Configuration pour que le scroll s'adapte à la taille du contenu
        def configure_scroll_region(event):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def configure_frame_width(event):
            canvas.itemconfig(inner_frame_id, width=event.width)

        self.inner_frame.bind("<Configure>", configure_scroll_region)
        canvas.bind("<Configure>", configure_frame_width)

        # Enregistrement des widgets pour le gestionnaire de thèmes
        self.theme_manager.register_widget(canvas, 'bg_main')
        self.theme_manager.register_widget(self.inner_frame, 'bg_main')

        # --- CONTENU MIS À JOUR SELON VOTRE TEXTE ---

        # Présentation générale
        self.create_section("Présentation générale", [
            "Afin de garantir une solution claire, évolutive et facilement maintenable, les fonctionnalités ont été regroupées en modules logiques et indépendants.",
            "Le système repose sur des outils open source robustes comme Nmap, Ansible, Paramiko ou encore des modules Python tels que psutil, ipaddress et threading, pour assurer à la fois efficacité, automatisation et simplicité d’utilisation."
        ])

        # Gestion des utilisateurs
        self.create_section("Gestion des utilisateurs", [
            "• Contrôle des accès via rôles et validation manuelle.",
            "• Création de comptes via une interface d’inscription et une authentification sécurisée.",
            "• Attribution du rôle (utilisateur ou administrateur) par l’administrateur principal.",
            "• Rôles :",
            "    - Utilisateur standard : accès restreint aux fonctionnalités essentielles.",
            "    - Administrateur : accès total aux modules, réglages et gestion des utilisateurs."
        ])

        # Détection des réseaux et équipements
        self.create_section("Détection et Découverte", [
            "• Détection des réseaux : Identifie automatiquement les plages d’adresses IPv4 disponibles sur les interfaces locales.",
            "• Scannage et découverte des équipements : Analyse les réseaux sélectionnés à l’aide de Nmap pour identifier les équipements actifs (adresses MAC, IP, noms d’hôtes).",
            "• Identification par constructeur : Classe les équipements détectés par fabricant (Cisco, MikroTik, etc.) pour des actions ciblées."
        ])

        # Planification et Sauvegarde
        self.create_section("Sauvegarde et Restauration des Configurations", [
            "• Planification des sauvegardes : Permet de définir un intervalle de temps personnalisable pour des sauvegardes régulières et automatisées via un module Python intégré.",
            "• Création automatique des playbooks Ansible pour chaque sauvegarde.",
            "• Restauration des configurations : Permet à l'administrateur de restaurer une configuration à partir d'un fichier, avec une vérification d'intégrité (SHA256) pour garantir la fiabilité.",
        ])
        
        # Supervision et Outils
        self.create_section("Supervision et Outils", [
            "• Supervision du système : Un tableau de bord en temps réel affiche les statistiques clés (équipements en ligne, pannes, sauvegardes...) et l'état des services critiques (SSH, FTP).",
            "• Détection des pannes : Vérifie en continu la joignabilité (ping) et la connexion SSH des équipements, et émet une alerte sonore en cas de panne.",
            "• Outils système intégrés : Permettent de gérer le serveur FTP local, la synchronisation des sauvegardes et la configuration d'Ansible.",
        ])


        # Détection des pannes
        self.create_section("Détection des Pannes et Supervision", [
            "• Surveillance continue : Le système vérifie l'état des équipements en arrière-plan.",
            "• Double vérification :",
            "    - Vérifie si l'équipement est joignable sur le réseau (test de ping).",
            "    - Vérifie si la connexion SSH est fonctionnelle avec les identifiants enregistrés.",
            "• Alerte sonore : Émet un son d'alarme distinct en cas de détection d'une panne, permettant une réaction rapide.",
            "• Tableau de bord en temps réel : Affiche les statistiques clés (pannes, équipements en ligne...) et l'état des services critiques (FTP, SSH)."
        ])

        # Personnalisation
        self.create_section("Paramètres d’interface", [
            "• Personnalisation de l’expérience utilisateur avec un choix de thèmes (clair/sombre).",
            "• Accès à une page d'aide et à la description détaillée des fonctionnalités."
        ])


    def create_section(self, title, lignes):
        """Crée une section avec un titre et une liste de points."""
        section = tk.LabelFrame(
            self.inner_frame,
            text=f" {title} ",  # Espaces pour l'esthétique
            font=("Helvetica", 14, "bold"),
            bg=self.theme_manager.bg_main,
            fg=self.theme_manager.fg_main,
            bd=2,
            relief="groove",
            padx=15,
            pady=10
        )
        section.pack(fill="x", padx=20, pady=10, expand=True)
        self.theme_manager.register_widget(section, 'bg_main', 'fg_main')

        for ligne in lignes:
            # Utiliser un Label pour un meilleur contrôle de l'habillage du texte
            label = tk.Label(
                section,
                text=ligne,
                anchor="w",
                justify="left",
                wraplength=self.inner_frame.winfo_width() - 60, # S'adapte à la largeur du frame
                font=("Helvetica", 12),
                bg=self.theme_manager.bg_main,
                fg=self.theme_manager.fg_main
            )
            label.pack(fill='x', anchor="w", pady=2)
            self.theme_manager.register_widget(label, 'bg_main', 'fg_main')

        # Liaison pour mettre à jour le wraplength lors du redimensionnement
        def rewrap(event, lbl=label):
            lbl.config(wraplength=self.inner_frame.winfo_width() - 60)
        self.inner_frame.bind("<Configure>", rewrap, add='+')