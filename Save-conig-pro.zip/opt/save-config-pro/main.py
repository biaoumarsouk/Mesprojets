from app import NetworkConfigApp

def main():
    """
    Fonction principale pour créer et lancer l'application.
    """
    app = NetworkConfigApp()
    app.mainloop()

if __name__ == "__main__":
    # Point d'entrée standard pour une application Python.
    main()