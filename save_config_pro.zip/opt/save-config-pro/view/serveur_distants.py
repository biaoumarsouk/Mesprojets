import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import paramiko
import subprocess
from datetime import datetime


class ServeursDistantsFrame(tk.Frame):
    def __init__(self, parent, theme_manager):
        super().__init__(parent, bg=theme_manager.bg_main)
        self.theme_manager = theme_manager
        self.theme_manager.register_widget(self, 'bg_main')
        self.parent = parent

        self.create_widgets()
        self.load_servers()
        self.insert_data()

    def create_widgets(self):
        """Crée l'interface des serveurs distants"""

        # Configuration de la grille principale
        self.grid_rowconfigure(0, weight=0)  # Titre + sous-titre
        self.grid_rowconfigure(1, weight=1)  # Tableau
        self.grid_rowconfigure(2, weight=0)  # Statut
        self.grid_columnconfigure(0, weight=1)

        # === Haut : titre + sous-titre
        top_frame = tk.Frame(self)
        top_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=(10, 0))
        top_frame.grid_columnconfigure(0, weight=1)
        self.theme_manager.register_widget(top_frame, 'bg_main')

        center_frame = tk.Frame(top_frame)
        center_frame.grid(row=0, column=0)
        self.theme_manager.register_widget(center_frame, 'bg_main')

        title = tk.Label(
            center_frame,
            text="\U0001F4BB Système de Gestion des Configurations Réseaux Informatiques",
            font=("Arial", 16, "bold")
        )
        title.pack()
        self.theme_manager.register_widget(title, 'bg_main', 'fg_main')

        self.mode_label = tk.Label(
            center_frame,
            text="Liste des serveurs enregistrés avec leur état actuel",
            font=("Arial", 14, "bold")
        )
        self.mode_label.pack(pady=5)
        self.theme_manager.register_widget(self.mode_label, 'bg_main', 'fg_main')

        # === Tableau Treeview
        self.table_frame = tk.Frame(self)
        self.table_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=10)
        self.table_frame.grid_rowconfigure(0, weight=1)
        self.table_frame.grid_columnconfigure(0, weight=1)
        self.theme_manager.register_widget(self.table_frame, 'bg_main')

        self.columns = ("Adresse IP", "Nom d'utilisateur", "État", "Fichiers")
        self.tree = ttk.Treeview(self.table_frame, columns=self.columns, show="headings")
        for col in self.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", stretch=True)

        self.scrollbar = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=self.scrollbar.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")

        self.tree.bind("<Configure>", self.adjust_column_widths)

        # === Statut (bas centré)
        self.status_frame = tk.Frame(self)
        self.status_frame.grid(row=2, column=0, pady=10, sticky="ew")
        self.theme_manager.register_widget(self.status_frame, 'bg_main')

        inner_status = tk.Frame(self.status_frame)
        inner_status.pack(anchor="center")
        self.theme_manager.register_widget(inner_status, 'bg_main')

        self.server_count_var = tk.StringVar(value="Serveurs détectés : 0")

        count_label = tk.Label(
            inner_status,
            textvariable=self.server_count_var,
            font=("Arial", 14, "bold")
        )
        count_label.pack(side="left", padx=20)
        self.theme_manager.register_widget(count_label, 'bg_main', 'fg_main')

        status_label = tk.Label(
            inner_status,
            text="État du système : OK",
            font=("Arial", 14, "bold")
        )
        status_label.pack(side="left", padx=20)
        self.theme_manager.register_widget(status_label, 'bg_main', 'fg_success')
        self.tree.bind("<Double-1>", self.on_server_click)


    def adjust_column_widths(self, event):
        total_width = event.width
        col_count = len(self.columns)
        if col_count > 0:
            for col in self.columns:
                self.tree.column(col, width=total_width // col_count)


    def load_servers(self):
        json_path = os.path.join(os.path.dirname(__file__), "files", "serveur_distants.json")
        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                self.servers = json.load(f)
        else:
            messagebox.showwarning("Aucun serveur", "Aucun fichier 'serveur_distants.json' trouvé.")

    def insert_data(self):
        self.tree.delete(*self.tree.get_children())

        for server in self.servers:
            ip = server.get("ip")
            username = server.get("username")
            password = server.get("password", "")
            remote_dir = f"/home/{username}/ftp_backups_distant"
            status = self.check_server_status(ip, username, password)
            file_count = self.get_file_count(ip, username, password, remote_dir)

            self.tree.insert("", "end", values=(ip, username, status, file_count))

        # ✅ Déplacer cette ligne ici
        self.server_count_var.set(f"Serveurs détectés : {len(self.servers)}")



    def check_server_status(self, ip, username, password):
        # Test de ping
        ping_cmd = ["ping", "-c", "1", "-W", "1", ip]
        ping_result = subprocess.run(ping_cmd, stdout=subprocess.DEVNULL)
        if ping_result.returncode != 0:
            return "❌ Hors ligne"

        # Test de SSH
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            if password:
                ssh.connect(ip, username=username, password=password, timeout=3)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=3)
            ssh.close()
            return "✅ En ligne"
        except:
            return "⚠️ Ping OK, SSH KO"

    def get_file_count(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            if password:
                ssh.connect(ip, username=username, password=password, timeout=3)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=3)

            sftp = ssh.open_sftp()
            files = sftp.listdir(remote_dir)
            count = len([
                f for f in files if f.lower().endswith((".cfg", ".rsc"))
            ])
            sftp.close()
            ssh.close()
            return count
        except:
            return "?"
    def on_server_click(self, event):
        selected_item = self.tree.selection()
        if not selected_item:
            return

        index = self.tree.index(selected_item[0])
        server = self.servers[index]
        self.open_server_detail(server)


    def open_server_detail(self, server):
        detail = tk.Toplevel(self)
        detail.title("Détails du serveur distant")
        detail.geometry("700x400")
        detail.transient(self.winfo_toplevel())
        detail.after(100, lambda: detail.grab_set())
        self.theme_manager.register_widget(detail, 'bg_main')

        detail.grid_rowconfigure(1, weight=1)
        detail.grid_columnconfigure(0, weight=1)

        ip = server.get("ip", "N/A")
        username = server.get("username", "N/A")
        password = server.get("password", "N/A")
        status = self.check_server_status(ip, username, password)
        remote_dir = f"/home/{username}/ftp_backups_distant"
        files = self.get_file_list(ip, username, password, remote_dir)
        nb_fichiers = len(files)
        files_hach = self.get_file_hachlist(ip, username, password, remote_dir)
        nb_hach = len(files_hach)

        # === Entête : infos serveur ===
        header_frame = tk.Frame(detail)
        header_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        header_frame.grid_columnconfigure((0, 1, 2), weight=1)
        self.theme_manager.register_widget(header_frame, 'bg_main')

        infos = [
            ("Adresse IP", ip),
            ("Nom d'utilisateur", username),
            ("Mot de passe", password),
            ("État", status),
            ("Nombre de fichiers", str(nb_fichiers)),
            ("Nombre de haché",str(nb_hach)),
        ]

        for i, (label, value) in enumerate(infos):
            f = tk.Frame(header_frame)
            f.grid(row=i // 3, column=i % 3, padx=5, pady=2, sticky="ew")
            self.theme_manager.register_widget(f, 'bg_main')

            lbl_label = tk.Label(f, text=label, font=("Arial", 9, "bold"))
            lbl_label.pack(anchor="w")
            self.theme_manager.register_widget(lbl_label, 'bg_main', 'fg_main')

            lbl_value = tk.Label(f, text=value, font=("Arial", 9))
            lbl_value.pack(anchor="w")
            self.theme_manager.register_widget(lbl_value, 'bg_main', 'fg_main')

            

        # === Liste des fichiers ===
        files_frame = tk.Frame(detail)
        files_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        self.theme_manager.register_widget(files_frame, 'bg_main')

        files_frame.grid_rowconfigure(0, weight=1)
        files_frame.grid_columnconfigure(0, weight=1)

        columns = ("Date", "Nom du fichier")
        tree = ttk.Treeview(files_frame, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")

        scrollbar = ttk.Scrollbar(files_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        for f, date in files:
            tree.insert("", "end", values=(date, f))

        # === Boutons Supprimer serveur / Vider fichiers ===
        btn_frame = tk.Frame(detail)
        btn_frame.grid(row=2, column=0, sticky="e", padx=10, pady=10)
        self.theme_manager.register_widget(btn_frame, 'bg_main')

        btn_vider = tk.Button(
            btn_frame,
            text="🗑️ Vider les fichiers",
            font=("Arial", 10, "bold"),
            command=lambda: self.vider_fichiers_serveur(ip, username, password, remote_dir, tree)
        )
        btn_vider.pack(side="left", padx=5)
        self.theme_manager.register_widget(btn_vider, 'bg_main','fg_main','bg_hover')

        btn_supprimer = tk.Button(
            btn_frame,
            text="🗑️ Supprimer ce serveur",
            font=("Arial", 10, "bold"),
            command=lambda: self.supprimer_serveur(server, detail)
        )
        btn_supprimer.pack(side="left", padx=5)
        self.theme_manager.register_widget(btn_supprimer,'bg_main','fg_main','bg_hover')


    def get_file_list(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            if password:
                ssh.connect(ip, username=username, password=password, timeout=3)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=3)

            sftp = ssh.open_sftp()
            file_list = []
            for f in sftp.listdir_attr(remote_dir):
                filename = f.filename
                date = self.format_date_ts(f.st_mtime)
                if filename.endswith((".cfg", ".rsc")):
                   file_list.append((f.filename, date))
            sftp.close()
            ssh.close()
            return file_list
        except Exception as e:
            print("Erreur get_file_list:", e)
            return []
        
    def get_file_hachlist(self, ip, username, password, remote_dir):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            if password:
                ssh.connect(ip, username=username, password=password, timeout=3)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=3)

            sftp = ssh.open_sftp()
            file_list = []
            for f in sftp.listdir_attr(remote_dir):
                filename = f.filename
                date = self.format_date_ts(f.st_mtime)
                if filename.endswith((".cfg.sha256",".rsc.sha256")):
                   file_list.append((f.filename, date))
            sftp.close()
            ssh.close()
            return file_list
        except Exception as e:
            print("Erreur get_file_list:", e)
            return []
    

    def format_date_ts(self, timestamp):
        try:
            return datetime.fromtimestamp(timestamp).strftime("%d/%m/%Y %H:%M")
        except:
            return "N/A"
    

    def vider_fichiers_serveur(self, ip, username, password, remote_dir, tree):
        if not messagebox.askyesno("Confirmation", "Voulez-vous supprimer tous les fichiers de sauvegarde sur ce serveur ?"):
            return
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            if password:
                ssh.connect(ip, username=username, password=password, timeout=3)
            else:
                ssh.connect(ip, username=username, key_filename=os.path.expanduser("~/.ssh/id_rsa"), timeout=3)
            cmd = f"rm -f {remote_dir}/*"
            ssh.exec_command(cmd)
            ssh.close()
            messagebox.showinfo("Succès", "Tous les fichiers ont été supprimés.")
            tree.delete(*tree.get_children())
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de supprimer les fichiers : {e}")
    


    def supprimer_serveur(self, server, window):
        if not messagebox.askyesno("Confirmation", "Voulez-vous vraiment supprimer ce serveur ?"):
            return
        try:
            self.servers = [s for s in self.servers if not (
                s.get("ip") == server.get("ip") and s.get("username") == server.get("username")
            )]
            json_path = os.path.join(os.path.dirname(__file__), "files", "serveur_distants.json")
            with open(json_path, "w") as f:
                json.dump(self.servers, f, indent=4)
            self.insert_data()
            window.destroy()
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de supprimer le serveur : {e}")
