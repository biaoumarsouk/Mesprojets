import os
import json
import paramiko
import socket
from tkinter import messagebox
import time  # à placer en haut du fichier


class EquipementProcessor:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.equipe_path = os.path.join(base_dir, 'equipe_save.json')

        self.mapping_fichiers = {
            "ios": "cisco_save.json",
            "asa": "cisco_save.json",
            "mikrotik": "mikrotik_save.json",
            "fortinet": "fortinet_save.json",
            "huawei": "huawei_save.json",
            "juniper": "juniper_save.json"
        }

        self.mapping_commandes = {
            "ios": "show version",
            "asa": "show version",
            "mikrotik": "/system resource print",
            "fortinet": "get system status",
            "huawei": "display version",
            "juniper": "show version"
        }

        self.mapping_keywords = {
            "mikrotik": ["routeros", "mikrotik"],
            "cisco": ["cisco ios", "cisco"],
            "ios": ["cisco ios", "router"],
            "asa": ["adaptive security", "cisco adaptive", "asa software", "asa version", "asav"],
            "huawei": ["huawei", "vrp"],
            "juniper": ["juniper", "junos"],
            "fortinet": ["fortigate", "fortinet", "fortios"]
        }

    def _create_compatible_ssh_client(self, ip, username, password, expected_type):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_args = {
            'hostname': ip,
            'username': username,
            'password': password,
            'timeout': 10,
            'look_for_keys': False,
            'allow_agent': False,
            'banner_timeout': 10
        }

        try:
            if expected_type.lower() in ["ios", "asa"]:
                try:
                    client.connect(**connect_args)
                    return client
                except paramiko.ssh_exception.SSHException:
                    print("   -> Connexion directe échouée, tentative Cisco fallback...")
                    transport = paramiko.Transport((ip, 22))
                    transport.connect(username=username, password=password)
                    security = transport.get_security_options()
                    security.ciphers += ('aes128-cbc', '3des-cbc', 'aes256-cbc')
                    security.key_types += ('ssh-rsa',)
                    client._transport = transport
                    return client
            else:
                client.connect(**connect_args)
                return client
        except Exception as e:
            raise e


    def detect_and_classify(self, equipment, expected_type):
        ip = equipment.get('ip')
        creds = equipment.get('credentials', {})
        username = creds.get('username')
        password = creds.get('password')
        enable_password = creds.get('enable_password', password)  # Fallback sur password

        if not all([ip, username, password, expected_type]):
            print(f"❌ Paramètres manquants pour {ip}.")
            return None

        client = None
        try:
            client = self._create_compatible_ssh_client(ip, username, password, expected_type)

            output = ""

            if expected_type.lower() == "asa":
                print(f"   -> Passage en mode enable pour {ip}")
                shell = client.invoke_shell()
                time.sleep(1)
                shell.send("enable\n")
                time.sleep(1)
                shell.send(f"{enable_password}\n")
                time.sleep(1)
                shell.send("terminal pager 0\n")
                time.sleep(1)
                shell.send("show version\n")
                time.sleep(3)
                output = shell.recv(65535).decode(errors="ignore").lower()

            elif expected_type.lower() == "ios":
                # Pour IOS, on entre en mode enable si nécessaire
                shell = client.invoke_shell()
                time.sleep(1)
                shell.send("enable\n")
                time.sleep(1)
                shell.send(f"{enable_password}\n")
                time.sleep(1)
                shell.send("terminal length 0\n")
                time.sleep(1)
                shell.send("show version\n")
                time.sleep(3)
                output = shell.recv(65535).decode(errors="ignore").lower()
            else:
                command = self.mapping_commandes.get(expected_type.lower(), "uname -a")
                print(f"   -> Envoi de la commande : {command}")
                stdin, stdout, stderr = client.exec_command(command, timeout=15)
                output = stdout.read().decode(errors="ignore").lower()

            keywords = self.mapping_keywords.get(expected_type.lower(), [])
            if any(kw.lower() in output for kw in keywords):
                print(f"✅ Type confirmé pour {ip} : {expected_type}")
                return expected_type
            else:
                print(f"⚠️ Type non confirmé pour {ip}.")
                return None

        except Exception as e:
            print(f"❌ Erreur SSH vers {ip} : {e}")
            return None
        finally:
            if client:
                client.close()


    def copy_to_correct_file(self, equipment, detected_type):
        type_key = detected_type.lower()
        filename = self.mapping_fichiers.get(type_key)

        if not filename:
            print(f"❌ Aucun fichier défini pour le type : {detected_type}")
            return

        target_path = os.path.join(self.base_dir, filename)
        data = []

        if os.path.exists(target_path):
            try:
                with open(target_path, 'r') as f:
                    data = json.load(f)
                    if not isinstance(data, list):
                        data = []
            except json.JSONDecodeError:
                print(f"⚠️ JSON corrompu dans {filename}, initialisation vide.")
                data = []

        mac = equipment.get('mac')
        found = False
        max_id = max((item.get('id', 0) for item in data), default=0)

        for i, eq in enumerate(data):
            if eq.get('mac') == mac:
                equipment['id'] = eq.get('id', max_id + 1)
                data[i] = equipment
                found = True
                break

        if not found:
            equipment['id'] = max_id + 1
            data.append(equipment)

        with open(target_path, 'w') as f:
            json.dump(data, f, indent=4)

        print(f"📁 Équipement '{equipment.get('name')}' copié/mis à jour dans {filename} avec ID {equipment['id']}")
