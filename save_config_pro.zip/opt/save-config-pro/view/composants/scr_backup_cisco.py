import os
import shutil
import json
import platform
import subprocess
from datetime import datetime
import psutil
import struct
import socket
import paramiko

# --- Fonctions utilitaires définies au niveau du module pour la clarté ---

def get_local_ip_in_subnet(subnet_cidr, all_interfaces):
    try:
        subnet_ip, subnet_mask = subnet_cidr.split('/')
        subnet_int = struct.unpack("!I", socket.inet_aton(subnet_ip))[0]
        mask_int = (0xFFFFFFFF << (32 - int(subnet_mask))) & 0xFFFFFFFF
    except (ValueError, socket.error):
        return None
    def ip_to_int(ip): return struct.unpack("!I", socket.inet_aton(ip))[0]
    for addrs in all_interfaces.values():
        for addr in addrs:
            if addr.family == socket.AF_INET:
                try:
                    if (ip_to_int(addr.address) & mask_int) == (subnet_int & mask_int):
                        return addr.address
                except socket.error: continue
    return None

def get_subnet_for_ip(ip, subnets):
    try:
        ip_int = struct.unpack("!I", socket.inet_aton(ip))[0]
        for subnet in subnets:
            subnet_ip, subnet_mask = subnet.split('/')
            subnet_int = struct.unpack("!I", socket.inet_aton(subnet_ip))[0]
            mask_int = (0xFFFFFFFF << (32 - int(subnet_mask))) & 0xFFFFFFFF
            if (ip_int & mask_int) == (subnet_int & mask_int):
                return subnet
    except (ValueError, socket.error): return None
    return None

def is_reachable(ip):
    param = "-n" if platform.system().lower() == "windows" else "-c"
    command = ['ping', param, '1', '-W', '1', ip]
    try:
        return subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    except Exception: return False

def test_ssh_connection(ip, username, password, timeout=3):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=ip, username=username, password=password, timeout=timeout, allow_agent=False, look_for_keys=False)
        client.close()
        return True
    except Exception: return False

def get_mac_from_arp(ip):
    try:
        output = subprocess.check_output(['arp', '-n', ip], text=True, stderr=subprocess.DEVNULL)
        for line in output.splitlines():
            if ip in line:
                parts = line.split()
                for part in parts:
                    if ':' in part and len(part) == 17:
                        return part.lower()
    except Exception: pass
    return None

# --- Fonction principale du module ---

def run_cisco_backup():
    """
    Génère les fichiers Ansible et exécute la sauvegarde pour les équipements Cisco.
    Retourne TOUJOURS un tuple (bool, str).
    """
    print("--- [BACKUP TASK] Démarrage de la tâche de sauvegarde Cisco ---")
    
    try:
        # --- [ÉTAPE 1] Chargement des configurations ---
        script_dir = os.path.dirname(os.path.abspath(__file__))
        networks_path = os.path.join(script_dir, '..', 'files', 'networks.json')
        json_file_cisco = os.path.join(script_dir, '..', 'files', 'cisco_save.json')

        with open(networks_path, 'r') as f:
            subnets_config = json.load(f)
        with open(json_file_cisco, 'r') as f:
            equipments_original = json.load(f)

        all_interfaces = psutil.net_if_addrs()
        subnet_ftp_map = {s: get_local_ip_in_subnet(s, all_interfaces) for s in subnets_config}
        subnet_ftp_map = {k: v for k, v in subnet_ftp_map.items() if v}

        if not subnet_ftp_map:
            return (False, "Impossible de détecter les IPs locales dans les sous-réseaux.")

        # --- [ÉTAPE 2] Validation des équipements ---
        valid_equipments = []
        for equipment in equipments_original:
            ip = equipment.get('ip')
            if not ip or not is_reachable(ip):
                equipment['sauvegarde'] = False
                continue
            
            expected_mac = equipment.get('mac', '').lower().replace("-", ":")
            actual_mac = get_mac_from_arp(ip)
            if not actual_mac or actual_mac != expected_mac:
                equipment['sauvegarde'] = False
                continue
            
            if not test_ssh_connection(ip, equipment.get('credentials', {}).get('username'), equipment.get('credentials', {}).get('password')):
                equipment['sauvegarde'] = False
                continue

            equipment['sauvegarde'] = True
            valid_equipments.append(equipment)
        
        with open(json_file_cisco, 'w') as f:
            json.dump(equipments_original, f, indent=4)
        
        if not valid_equipments:
            return (True, "Aucun équipement Cisco valide à sauvegarder.")

        # --- [ÉTAPE 3] Création des fichiers Ansible ---
        print(f"   -> {len(valid_equipments)} équipement(s) valide(s) trouvé(s). Génération des fichiers...")
        backup_parent_dir = os.path.join(script_dir, '..', 'files', 'backup_cisco')
        if os.path.exists(backup_parent_dir):
            shutil.rmtree(backup_parent_dir)
        os.makedirs(backup_parent_dir)

        equipments_by_subnet = {subnet: [] for subnet in subnet_ftp_map}
        equipments_by_subnet["unknown"] = []
        for eq in valid_equipments:
            subnet = get_subnet_for_ip(eq['ip'], subnet_ftp_map.keys())
            if subnet: equipments_by_subnet[subnet].append(eq)
            else: equipments_by_subnet["unknown"].append(eq)
        
        current_date = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        
        for subnet, equipments_in_subnet in equipments_by_subnet.items():
            if not equipments_in_subnet: continue
            
            ftp_ip = subnet_ftp_map.get(subnet, "0.0.0.0")
            subnet_dir_name = f'backup_cisco_{ftp_ip.replace(".", "_")}' if subnet != "unknown" else 'backup_cisco_unknown'
            subnet_dir_path = os.path.join(backup_parent_dir, subnet_dir_name)
            os.makedirs(subnet_dir_path, exist_ok=True)
            
            inventory = [f"# Fichier généré le {current_date}", f"# Sous-réseau: {subnet}", f"# Serveur FTP: {ftp_ip}\n"]
            groupes = {"IOS": [], "ASA": []}
            for eq in equipments_in_subnet:
                equip_type = eq.get("system", "").upper()
                mac = eq.get('mac', '').replace(":", "-")
                ip_addr = eq.get('ip')
                username = eq['credentials']['username']
                password = eq['credentials']['password']
                enable_pwd = eq['credentials'].get('enable_password')

                if equip_type in ["IOS", "ASA"]:
                    base_line = f"{mac} ansible_host={ip_addr} ansible_user={username} ansible_ssh_pass={password} ansible_connection=network_cli"
                    if equip_type == "IOS":
                        base_line += " ansible_network_os=cisco.ios.ios"
                    else: # ASA
                        base_line += " ansible_network_os=cisco.asa.asa"
                    
                    if enable_pwd:
                        base_line += f" ansible_become=yes ansible_become_method=enable ansible_become_password={enable_pwd}"
                    
                    groupes[equip_type].append(base_line)
            
            if groupes["IOS"]:
                inventory.append("\n[ciscoios]")
                inventory.extend(groupes["IOS"])
            if groupes["ASA"]:
                inventory.append("\n[ciscoasa]")
                inventory.extend(groupes["ASA"])
            
            with open(os.path.join(subnet_dir_path, 'inventory.ini'), 'w') as f:
                f.write("\n".join(inventory))

            with open(os.path.join(subnet_dir_path, 'ansible.cfg'), 'w') as f:
                f.write(f"# Configuration générée le {current_date}\n"
                        f"# Pour le sous-réseau: {subnet}\n"
                        "[defaults]\n"
                        "ssh_args = -o KexAlgorithms=+diffie-hellman-group14-sha1,diffie-hellman-group1-sha1 -o HostKeyAlgorithms=+ssh-rsa -o Ciphers=+aes128-cbc,aes192-cbc,aes256-cbc,3des-cbc\n"
                        "host_key_checking = False\n"
                        "\n[network_cli]\n"
                        "timeout = 60\n")

            playbook_content = f"""---
# Playbook généré le {current_date}
# Pour le sous-réseau: {subnet}
# Serveur FTP: {ftp_ip}

- name: Sauvegarde des configurations Cisco IOS via FTP
  hosts: ciscoios
  gather_facts: no
  vars:
    ftp_server: "{ftp_ip}"
    ftp_username: "ftpuser"
    ftp_password: "Saveconfig57"
    current_date: "{{{{ lookup('pipe', 'date +%Y-%m-%d_%H-%M-%S') }}}}"
  tasks:
    - name: Copier la configuration vers le serveur FTP
      cisco.ios.ios_command:
        commands:
          - "copy running-config ftp://{{{{ ftp_username }}}}:{{{{ ftp_password }}}}@{{{{ ftp_server }}}}/cisco_ios_{{{{ inventory_hostname }}}}_{{{{ current_date }}}}.cfg\\n\\n"
      register: result
      ignore_errors: yes

- name: Sauvegarde de la configuration Cisco ASA vers FTP
  hosts: ciscoasa
  gather_facts: no
  vars:
    ftp_server: "{ftp_ip}"
    ftp_username: "ftpuser"
    ftp_password: "Saveconfig57"
    backup_filename: "cisco_asa_{{{{ inventory_hostname_short }}}}_{{{{ lookup('pipe', 'date +%Y-%m-%d_%H-%M-%S') }}}}.cfg"
  tasks:
    - name: Exécuter la sauvegarde vers FTP
      cisco.asa.asa_command:
        commands:
          - "copy /noconfirm running-config ftp://{{{{ ftp_username }}}}:{{{{ ftp_password }}}}@{{{{ ftp_server }}}}/{{{{ backup_filename }}}}"
      register: backup_result
      ignore_errors: yes
"""
            with open(os.path.join(subnet_dir_path, 'backup_cisco_ftp.yml'), 'w') as f:
                f.write(playbook_content)
        
    except FileNotFoundError as e:
        msg = f"Fichier de configuration manquant : {os.path.basename(e.filename)}"
        print(f"ERREUR: {msg}")
        return (False, msg)
    except Exception as e:
        msg = f"Erreur inattendue lors de la sauvegarde Cisco : {type(e).__name__} - {e}"
        print(f"ERREUR: {msg}")
        return (False, msg)

    return (True, f"{len(valid_equipments)} équipement(s) Cisco sauvegardé(s) avec succès.")
