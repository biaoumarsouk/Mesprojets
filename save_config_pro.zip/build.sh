#!/bin/bash

# Le script s'arrête immédiatement si une commande échoue
set -e

# --- Variables de configuration ---
APP_NAME="save-config-pro"
VERSION="1.0-1"
ARCH="amd64" # Important : les .so compilés sont spécifiques à l'architecture
DEB_NAME="${APP_NAME}_${VERSION}" # dpkg ajoutera _${ARCH} automatiquement
BUILD_DIR="build_temp" # Dossier de construction temporaire

# --- [ÉTAPE 1] Nettoyage et préparation ---
echo "🧹 Nettoyage des anciens builds..."
rm -rf "$BUILD_DIR"
find . -maxdepth 1 -name "*.deb" -delete
mkdir -p "$BUILD_DIR"
echo "   -> Dossier de build propre créé."

# --- [ÉTAPE 2] Compilation du code source avec Cython ---
echo "🤖 Compilation du code Python en modules .so..."

# Créer un dossier temporaire propre pour la compilation
SRC_COMPILE_DIR="$BUILD_DIR/source_to_compile"
mkdir -p "$SRC_COMPILE_DIR"

# --- MODIFICATION ICI ---
# On utilise rsync pour avoir un contrôle fin sur ce qui est copié.
# On copie tout depuis opt/save-config-pro SAUF les fichiers .json.
echo "   -> Copie des sources (SAUF les .json) vers le dossier de compilation..."
rsync -a --exclude='*.json' opt/save-config-pro/ "$SRC_COMPILE_DIR/"
cp setup.py "$SRC_COMPILE_DIR/"
# -------------------------

# Se déplacer dans le dossier de compilation
cd "$SRC_COMPILE_DIR"

# Lancer la compilation
echo "   -> Lancement de Cython (build_ext --inplace)..."
python3 setup.py build_ext --inplace

# Nettoyer le dossier de compilation
echo "   -> Suppression des fichiers .py, .c, et des outils de build..."
find . -type f -name "*.py" ! -name "main.py" ! -name "__init__.py" -delete
find . -type f -name "*.c" -delete
rm -f setup.py
rm -rf build/ __pycache__/

# Revenir à la racine du projet
cd ../..
echo "   -> Compilation et nettoyage terminés."

# --- [ÉTAPE 3] Assemblage de la structure finale du paquet .deb ---
echo "📦 Assemblage de la structure du paquet final..."
DEB_STRUCTURE="$BUILD_DIR/$DEB_NAME"

# Créer l'arborescence de destination
mkdir -p "$DEB_STRUCTURE/opt/$APP_NAME"
mkdir -p "$DEB_STRUCTURE/usr/local/bin"
mkdir -p "$DEB_STRUCTURE/usr/share/applications"
mkdir -p "$DEB_STRUCTURE/usr/share/icons/hicolor/64x64/apps"

# Copier le code compilé (qui ne contient plus les .json)
echo "   -> Copie du code compilé..."
cp -r "$SRC_COMPILE_DIR"/* "$DEB_STRUCTURE/opt/$APP_NAME/"

# Copier les fichiers de configuration du paquet
echo "   -> Copie des fichiers de configuration (DEBIAN, .desktop...)..."
cp -r DEBIAN "$DEB_STRUCTURE/"
cp -r usr/* "$DEB_STRUCTURE/usr/"

# Appliquer les bonnes permissions
echo "   -> Application des permissions exécutables..."
chmod 755 "$DEB_STRUCTURE/DEBIAN/postinst"
if [ -f "$DEB_STRUCTURE/DEBIAN/prerm" ]; then
    chmod 755 "$DEB_STRUCTURE/DEBIAN/prerm"
fi
if [ -f "$DEB_STRUCTURE/usr/local/bin/save-config-pro" ]; then
    chmod 755 "$DEB_STRUCTURE/usr/local/bin/save-config-pro"
fi

# Mettre à jour l'architecture dans le fichier control
echo "   -> Mise à jour de l'architecture vers '$ARCH' dans le fichier control..."
sed -i "s/Architecture: all/Architecture: $ARCH/" "$DEB_STRUCTURE/DEBIAN/control"

# --- [ÉTAPE 4] Construction du paquet .deb ---
echo "🎁 Construction du fichier .deb..."
dpkg-deb --build --root-owner-group "$DEB_STRUCTURE"

# Déplacer le paquet final à la racine du projet
# dpkg-deb nommera automatiquement le fichier avec l'architecture
mv "${BUILD_DIR}/${DEB_NAME}.deb" .

echo "✅ Terminé ! Paquet créé : ${DEB_NAME}.deb"