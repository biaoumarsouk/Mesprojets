# setup.py
from setuptools import setup
from Cython.Build import cythonize
import os

def find_py_files(base_dir):
    py_files = []
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            if file.endswith(".py") and "__init__" not in file:
                py_files.append(os.path.join(root, file))
    return py_files

py_files = find_py_files(".")

setup(
    ext_modules=cythonize(py_files, compiler_directives={"language_level": "3"})
)
